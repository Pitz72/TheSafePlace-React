// MainMenu.jsx — The Safe Place main menu, two variants
// Variant A: "Polaroid + Pinned Notes" — corkboard feel
// Variant B: "Journal Cover" — single leather/paper journal with embossed title

function MainMenuA() {
  const items = [
    { k: "NUOVA PARTITA", note: "scrivi il primo nome" },
    { k: "CONTINUA", note: "Giorno 14 · Le Spine" },
    { k: "CARICA", note: "5 fogli rimasti" },
    { k: "OPZIONI", note: null },
    { k: "TROFEI", note: "11 / 50" },
    { k: "ESCI", note: null },
  ];
  return (
    <div style={{ width: "100%", height: "100%", position: "relative", background: "#1a1d22", overflow: "hidden" }}>
      {/* deep dark base — a desk in low light */}
      <div style={{
        position: "absolute", inset: 0,
        background: `
          radial-gradient(ellipse 60% 50% at 50% 35%, rgba(120,130,145,0.18), transparent 70%),
          radial-gradient(ellipse 80% 60% at 50% 100%, rgba(0,0,0,0.6), transparent 70%),
          linear-gradient(180deg, #1d2127 0%, #14171c 100%)
        `
      }}/>

      {/* desk grain */}
      <div style={{
        position: "absolute", inset: 0, opacity: 0.18,
        backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='400' height='400'><filter id='n'><feTurbulence baseFrequency='0.7' numOctaves='2' seed='5'/></filter><rect width='400' height='400' filter='url(%23n)'/></svg>\")",
        mixBlendMode: "soft-light"
      }}/>

      {/* central "found object" — the journal */}
      <div style={{
        position: "absolute",
        left: "50%",
        top: "50%",
        transform: "translate(-50%, -50%) rotate(-2deg)",
        width: 420, height: 540,
        background: "var(--tsp-paper)",
        backgroundImage: `
          radial-gradient(ellipse 70% 50% at 30% 20%, rgba(255,255,255,0.18), transparent 60%),
          radial-gradient(ellipse 12% 9% at 78% 14%, rgba(74,52,32,0.20), transparent 80%),
          radial-gradient(ellipse 60% 40% at 80% 90%, rgba(0,0,0,0.10), transparent 70%)
        `,
        boxShadow: "0 24px 50px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,0,0,0.4), inset 0 0 60px rgba(0,0,0,0.08)",
        padding: "48px 44px 36px",
        display: "flex", flexDirection: "column", justifyContent: "space-between"
      }}>
        {/* paper noise */}
        <div style={{
          position: "absolute", inset: 0, pointerEvents: "none",
          backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence baseFrequency='0.9' numOctaves='2'/></filter><rect width='200' height='200' filter='url(%23n)' opacity='0.55'/></svg>\")",
          mixBlendMode: "multiply", opacity: 0.22
        }}/>

        {/* tape */}
        <Tape top={-12} left={170} w={90} h={26} rot={-6}/>

        <div style={{ position: "relative", textAlign: "center" }}>
          <div className="t-sans" style={{ fontSize: 11, letterSpacing: "0.5em", color: "var(--tsp-slate)", marginBottom: 18 }}>
            APPUNTI · ESTATE
          </div>
          <hr className="ink-rule" style={{ width: "40%", margin: "0 auto 24px" }}/>
          <div className="t-serif" style={{
            fontSize: 56, lineHeight: 0.95, fontWeight: 500, letterSpacing: "-0.01em",
            color: "var(--tsp-ink)"
          }}>
            The Safe<br/>Place
          </div>
          <div className="t-hand" style={{ fontSize: 22, color: "var(--tsp-rust)", marginTop: 14, opacity: 0.9 }}>
            — se mai esiste —
          </div>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.32em", color: "var(--tsp-slate-light)", marginTop: 26 }}>
            UN'AVVENTURA NARRATIVA DI SOPRAVVIVENZA
          </div>
        </div>

        {/* menu items */}
        <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: 1, marginTop: 28 }}>
          {items.map((it, i) => (
            <div key={i} style={{
              display: "flex", justifyContent: "space-between", alignItems: "baseline",
              padding: "10px 0",
              borderBottom: "1px solid rgba(20,24,30,0.18)",
              background: i === 1 ? "rgba(125,58,42,0.06)" : "transparent",
              cursor: "pointer"
            }}>
              <div style={{ display: "flex", alignItems: "baseline", gap: 14 }}>
                {i === 1 && <div style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--tsp-rust)", display: "inline-block" }}/>}
                <div className="t-sans" style={{
                  fontSize: 17,
                  letterSpacing: i === 1 ? "0.28em" : "0.22em",
                  fontWeight: i === 1 ? 600 : 500,
                  color: "var(--tsp-ink)"
                }}>{it.k}</div>
              </div>
              {it.note && (
                <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", opacity: 0.85 }}>
                  {it.note}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* footer */}
        <div style={{ position: "relative", display: "flex", justifyContent: "space-between", marginTop: 16 }}>
          <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.3em", color: "var(--tsp-slate-light)" }}>v2.0.5 · STABLE</div>
          <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)" }}>S.P.</div>
        </div>
      </div>

      {/* surrounding scraps */}
      {/* polaroid top-left */}
      <div style={{
        position: "absolute", left: 70, top: 90, width: 180, height: 210,
        background: "#d8d2c2",
        padding: "12px 12px 36px",
        transform: "rotate(-7deg)",
        boxShadow: "0 12px 24px rgba(0,0,0,0.55), inset 0 0 0 1px rgba(0,0,0,0.15)"
      }}>
        <div className="tsp-photo" style={{ width: "100%", height: "100%" }}>
          {/* silhouette */}
          <svg viewBox="0 0 100 100" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
            <defs>
              <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3a444f"/>
                <stop offset="100%" stopColor="#1a2028"/>
              </linearGradient>
            </defs>
            <rect width="100" height="100" fill="url(#sky)"/>
            <path d="M 0 75 L 12 70 L 18 72 L 25 60 L 38 65 L 45 55 L 58 60 L 70 50 L 82 55 L 90 60 L 100 58 L 100 100 L 0 100 Z"
                  fill="#0e1217" opacity="0.95"/>
            <circle cx="68" cy="34" r="3" fill="#e0e8ee" opacity="0.5"/>
          </svg>
        </div>
        <div className="t-hand" style={{ position: "absolute", bottom: 6, left: 14, fontSize: 13, color: "var(--tsp-slate)" }}>
          ovest, il primo giorno
        </div>
        <Tape top={-10} left={60} w={50} h={18} rot={6}/>
      </div>

      {/* small note bottom-right */}
      <div style={{
        position: "absolute", right: 90, top: 130, width: 220, height: 100,
        background: "#cfc8b6",
        padding: 14,
        transform: "rotate(4deg)",
        boxShadow: "0 8px 18px rgba(0,0,0,0.45)"
      }}>
        <div className="t-hand" style={{ fontSize: 15, color: "var(--tsp-ink)", lineHeight: 1.25 }}>
          "Non fidarti delle stanze<br/>silenziose. Il silenzio<br/>è ciò che li attira."
        </div>
        <div className="t-sans" style={{ fontSize: 9, color: "var(--tsp-slate-light)", letterSpacing: "0.2em", marginTop: 8 }}>— PAPÀ</div>
        <Pin top={-7} right={28} variant="rust"/>
      </div>

      {/* dog tag / key bottom-left */}
      <div style={{ position: "absolute", left: 110, bottom: 80, transform: "rotate(18deg)", width: 140, opacity: 0.85 }}>
        <svg viewBox="0 0 140 60">
          <rect x="2" y="14" width="100" height="34" rx="17" fill="#7a7e84" stroke="#3a3e44" strokeWidth="1.5"/>
          <circle cx="118" cy="31" r="11" fill="none" stroke="#3a3e44" strokeWidth="1.5"/>
          <text x="52" y="32" textAnchor="middle" fontFamily="var(--tsp-sans)" fontSize="9" fill="#1a1d22" letterSpacing="2">CT-014</text>
          <text x="52" y="42" textAnchor="middle" fontFamily="var(--tsp-sans)" fontSize="7" fill="#1a1d22" letterSpacing="1">PROG. ECO</text>
        </svg>
      </div>

      {/* footer bar */}
      <div style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        padding: "14px 24px",
        display: "flex", justifyContent: "space-between", alignItems: "center",
        color: "var(--tsp-paper-edge)",
        background: "linear-gradient(180deg, transparent, rgba(0,0,0,0.5))"
      }}>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.32em" }}>↑ ↓ NAVIGA · ↵ SELEZIONA · ESC ESCI</div>
        <div className="t-hand" style={{ fontSize: 14 }}>— sopravvissuto n. 014 —</div>
      </div>
    </div>
  );
}

function MainMenuB() {
  const items = [
    "NUOVA PARTITA",
    "CONTINUA",
    "CARICA",
    "OPZIONI",
    "TROFEI",
    "STORIA",
    "ESCI",
  ];
  const [hover, setHover] = useState(1);

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", background: "#0e1115", overflow: "hidden" }}>
      {/* atmospheric bg — distant ruined skyline */}
      <svg viewBox="0 0 1280 720" preserveAspectRatio="xMidYMid slice"
           style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.6 }}>
        <defs>
          <linearGradient id="mmSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2a3340"/>
            <stop offset="55%" stopColor="#3a4654"/>
            <stop offset="100%" stopColor="#1a2028"/>
          </linearGradient>
          <linearGradient id="mmFog" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="rgba(180,195,210,0.0)"/>
            <stop offset="100%" stopColor="rgba(180,195,210,0.35)"/>
          </linearGradient>
        </defs>
        <rect width="1280" height="720" fill="url(#mmSky)"/>
        {/* sun behind cloud */}
        <circle cx="900" cy="220" r="80" fill="#a8b2bc" opacity="0.18"/>
        {/* distant skyline */}
        <g fill="#161a22" opacity="0.95">
          <rect x="0" y="450" width="1280" height="270"/>
          <polygon points="80,450 90,380 110,380 120,450"/>
          <polygon points="150,450 165,400 175,395 185,400 190,450"/>
          <polygon points="220,450 230,360 250,340 280,355 290,450"/>
          <polygon points="320,450 330,420 350,420 360,450"/>
          <polygon points="400,450 420,330 460,310 490,340 500,450"/>
          <polygon points="540,450 555,400 570,380 590,395 600,450"/>
          <polygon points="640,450 655,380 685,350 720,370 735,450"/>
          <polygon points="780,450 800,380 830,360 855,375 870,450"/>
          <polygon points="900,450 920,400 945,380 970,400 985,450"/>
          <polygon points="1020,450 1035,360 1075,340 1110,355 1125,450"/>
          <polygon points="1160,450 1175,400 1200,380 1220,400 1240,450"/>
        </g>
        {/* tilted antenna / cross */}
        <line x1="475" y1="335" x2="465" y2="240" stroke="#161a22" strokeWidth="2"/>
        <line x1="450" y1="270" x2="490" y2="280" stroke="#161a22" strokeWidth="1.5"/>
        {/* fog */}
        <rect y="380" width="1280" height="340" fill="url(#mmFog)"/>
      </svg>

      {/* foreground silhouette — figure walking */}
      <svg viewBox="0 0 1280 720" preserveAspectRatio="xMidYMid slice"
           style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        <g fill="#0a0d12" opacity="0.95">
          {/* ground */}
          <path d="M 0 600 L 1280 580 L 1280 720 L 0 720 Z"/>
          {/* lone figure off-center */}
          <g transform="translate(960 510)">
            <path d="M -8 0 L 8 0 L 6 70 L -6 70 Z"/>
            <ellipse cx="0" cy="-10" rx="9" ry="12"/>
            <path d="M -12 8 L -22 38 L -18 60 L -8 35 Z"/>
            <path d="M 4 6 L 18 28 L 28 18 L 12 -4 Z"/>
            <line x1="22" y1="20" x2="18" y2="-32" stroke="#0a0d12" strokeWidth="2.5"/>
          </g>
        </g>
      </svg>

      {/* particles / cold dust */}
      {Array.from({ length: 30 }).map((_, i) => (
        <div key={i} style={{
          position: "absolute",
          width: 1 + (i % 3),
          height: 1 + (i % 3),
          left: `${(i * 37) % 100}%`,
          top: `${(i * 23) % 90}%`,
          background: "rgba(220,228,235,0.45)",
          borderRadius: "50%",
          opacity: 0.3 + ((i * 7) % 5) / 10
        }}/>
      ))}

      {/* large title — letterpress feel */}
      <div style={{ position: "absolute", left: 80, top: 100, color: "var(--tsp-paper)" }}>
        <div className="t-sans" style={{ fontSize: 11, letterSpacing: "0.6em", opacity: 0.55, marginBottom: 18 }}>
          UN GIOCO NARRATIVO DI SOPRAVVIVENZA
        </div>
        <div className="t-serif" style={{
          fontSize: 130, lineHeight: 0.86, fontWeight: 500, letterSpacing: "-0.02em",
          textShadow: "0 2px 0 rgba(0,0,0,0.4)"
        }}>
          The Safe<br/>
          <em style={{ fontStyle: "italic", color: "var(--tsp-ice-glow)" }}>Place</em>
        </div>
        <div className="t-hand" style={{ fontSize: 28, color: "var(--tsp-rust)", marginTop: 10, opacity: 0.95 }}>
          se mai esiste.
        </div>
      </div>

      {/* menu — vertical list, lower-left */}
      <div style={{ position: "absolute", left: 80, bottom: 80, display: "flex", flexDirection: "column", gap: 4 }}>
        {items.map((label, i) => {
          const active = hover === i;
          return (
            <div
              key={label}
              onMouseEnter={() => setHover(i)}
              style={{
                display: "flex", alignItems: "baseline", gap: 16,
                color: active ? "var(--tsp-paper)" : "rgba(216,210,194,0.45)",
                cursor: "pointer",
                padding: "4px 0",
                transition: "all 0.2s ease"
              }}
            >
              <div style={{
                width: active ? 36 : 14,
                height: 1,
                background: active ? "var(--tsp-rust)" : "rgba(216,210,194,0.4)",
                transition: "width 0.25s ease"
              }}/>
              <div className="t-sans" style={{
                fontSize: 22,
                letterSpacing: active ? "0.32em" : "0.22em",
                fontWeight: active ? 600 : 500,
                transition: "letter-spacing 0.25s ease"
              }}>
                {label}
              </div>
              {active && i === 1 && (
                <div className="t-hand" style={{ fontSize: 18, color: "var(--tsp-mint)", marginLeft: 16, opacity: 0.85 }}>
                  Giorno 14 · Le Spine
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* small pinned card — right side */}
      <div style={{
        position: "absolute", right: 90, top: 140, width: 280, padding: 22,
        background: "rgba(216,210,194,0.06)",
        border: "1px solid rgba(216,210,194,0.18)",
        backdropFilter: "blur(6px)",
        color: "var(--tsp-paper)"
      }}>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.32em", opacity: 0.6, marginBottom: 12 }}>
          ULTIMA VOCE · DIARIO
        </div>
        <div className="t-serif" style={{ fontSize: 16, lineHeight: 1.5, fontStyle: "italic", color: "#e8eaed" }}>
          "Il quattordicesimo giorno. La pioggia è cessata.
          Vedo qualcosa muoversi tra le rovine a est — forse
          una persona, forse no. Domani lo saprò."
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 16, fontSize: 10, letterSpacing: "0.2em", color: "rgba(216,210,194,0.55)" }}>
          <span className="t-sans">CAP. III · LE SPINE</span>
          <span className="t-sans">06:42</span>
        </div>
      </div>

      {/* footer */}
      <div style={{ position: "absolute", bottom: 24, left: 0, right: 0, display: "flex", justifyContent: "space-between", padding: "0 80px" }}>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.4em", color: "rgba(216,210,194,0.45)" }}>
          ↑ ↓ NAVIGA   ·   ↵ SELEZIONA   ·   ESC ESCI
        </div>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.4em", color: "rgba(216,210,194,0.45)" }}>
          v3.0 · "DIARIO" REMASTER
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { MainMenuA, MainMenuB });
