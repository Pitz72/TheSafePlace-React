// Crafting.jsx — workshop bench

function Crafting() {
  const recipes = [
    { name: "Bende Pulite",        sub: "cura · base",       have: true,  out: "+ 1 Benda Pulita" },
    { name: "Torcia",              sub: "utility · base",    have: true,  out: "+ 1 Torcia" },
    { name: "Acqua Purificata",    sub: "consumabile",       have: true,  out: "+ 1 Acqua Pulita" },
    { name: "Frecce",              sub: "munizioni · arco",  have: true,  out: "+ 4 Frecce" },
    { name: "Coltello da Lancio",  sub: "arma · destrezza",  have: false, out: "+ 1 Coltello Lanc.", missing: "scotch" },
    { name: "Zuppa Calda",         sub: "consumabile",       have: true,  out: "+ 1 Zuppa (sazia)" },
    { name: "Kit di Riparazione",  sub: "utility · raro",    have: false, out: "+ 1 Kit", missing: "olio motore" },
  ];
  const [sel, setSel] = useState(0);

  return (
    <div style={{ position: "relative", width: "100%", height: "100%", background: "#0e1115", overflow: "hidden" }}>
      <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(ellipse 60% 50% at 50% 40%, rgba(120,130,145,0.12), transparent 70%), linear-gradient(180deg, #181b21, #0e1115)"
      }}/>

      {/* book — two pages */}
      <div style={{
        position: "absolute", left: 24, right: 24, top: 24, bottom: 24,
        display: "flex",
        background: "var(--tsp-paper)",
        boxShadow: "0 30px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,0,0,0.4)"
      }}>
        <div style={{ position: "absolute", left: "50%", top: 0, bottom: 0, width: 40, transform: "translateX(-50%)", background: "radial-gradient(ellipse 100% 100% at center, rgba(20,24,30,0.35), transparent 70%)", pointerEvents: "none", zIndex: 10 }}/>
        <div style={{ position: "absolute", left: "50%", top: 0, bottom: 0, width: 2, background: "rgba(20,24,30,0.55)", transform: "translateX(-50%)", zIndex: 11 }}/>

        {/* LEFT — recipe index */}
        <div className="paper" style={{ flex: 1, padding: "32px 36px 32px 44px", position: "relative" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", borderBottom: "1.5px solid var(--tsp-ink)", paddingBottom: 8, marginBottom: 18 }}>
            <div>
              <div className="t-label">MANUALE DI CRAFTING</div>
              <div className="t-serif" style={{ fontSize: 28, lineHeight: 1, fontWeight: 500 }}>Cosa so fare.</div>
            </div>
            <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)" }}>
              7 ricette · 2 in attesa
            </div>
          </div>

          <div className="t-label-sm" style={{ marginBottom: 8 }}>RICETTE CONOSCIUTE</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
            {recipes.map((r, i) => {
              const active = i === sel;
              return (
                <div
                  key={r.name}
                  onClick={() => setSel(i)}
                  style={{
                    display: "flex", alignItems: "baseline", gap: 12,
                    padding: "10px 8px 9px",
                    borderBottom: "1px dashed rgba(20,24,30,0.22)",
                    background: active ? "rgba(125,58,42,0.08)" : "transparent",
                    cursor: "pointer",
                    opacity: r.have ? 1 : 0.55
                  }}
                >
                  {active && <span style={{ color: "var(--tsp-rust)", fontSize: 14 }}>›</span>}
                  <div style={{ flex: 1 }}>
                    <div className="t-serif" style={{ fontSize: 16, lineHeight: 1.2 }}>{r.name}</div>
                    <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.16em", color: "var(--tsp-slate)" }}>{r.sub}</div>
                  </div>
                  <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.18em", color: r.have ? "var(--tsp-mint)" : "var(--tsp-rust)" }}>
                    {r.have ? "PRONTA" : "MANCA"}
                  </div>
                </div>
              );
            })}
          </div>

          <hr className="ink-rule-dashed" style={{ margin: "18px 0 12px" }}/>
          <div className="t-label-sm" style={{ marginBottom: 6 }}>MANUALI SCOPERTI</div>
          <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-ink)", lineHeight: 1.5 }}>
            · Manuale dell'Acqua (Olivia)<br/>
            · Manuale del Fuoco (rifugio Crocevia)<br/>
            <span style={{ color: "var(--tsp-slate)", fontStyle: "italic" }}>· 4 ricette ancora da trovare</span>
          </div>

          <div style={{ position: "absolute", bottom: 16, left: 44, right: 36 }}>
            <span className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>↑ ↓ NAVIGA · ↵ CREA · ESC CHIUDI · — pag. 60 —</span>
          </div>
        </div>

        {/* RIGHT — detail of selected recipe */}
        <div className="paper" style={{ flex: 1, padding: "32px 44px 32px 36px", position: "relative" }}>
          <div className="t-label" style={{ marginBottom: 6 }}>SUL TAVOLO</div>
          <div className="t-serif" style={{ fontSize: 32, lineHeight: 1, fontWeight: 500, marginBottom: 4 }}>
            {recipes[sel].name}
          </div>
          <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", marginBottom: 14 }}>
            {recipes[sel].sub}
          </div>

          {/* drawing of the output */}
          <div style={{
            width: "100%", aspectRatio: "16/8",
            border: "1.5px solid var(--tsp-ink)",
            background: "rgba(255,255,255,0.35)",
            position: "relative", marginBottom: 16,
            display: "flex", alignItems: "center", justifyContent: "center"
          }}>
            <svg viewBox="0 0 200 100" style={{ width: "60%", height: "60%" }}>
              <g fill="none" stroke="var(--tsp-ink)" strokeWidth="1.5">
                {sel === 0 && <>
                  <ellipse cx="100" cy="50" rx="40" ry="38" fill="rgba(216,210,194,0.5)"/>
                  <path d="M 60 40 Q 100 22 140 46" stroke="var(--tsp-rust)" strokeWidth="2" opacity="0.6"/>
                </>}
                {sel === 1 && <>
                  <line x1="50" y1="80" x2="130" y2="30" strokeWidth="2"/>
                  <ellipse cx="135" cy="25" rx="15" ry="10" fill="rgba(232,210,170,0.4)"/>
                  <path d="M 130 18 Q 138 8 146 18" strokeWidth="1.5" fill="rgba(125,58,42,0.4)"/>
                </>}
                {sel === 2 && <>
                  <path d="M 80 30 L 80 70 L 120 70 L 120 30 Z" fill="rgba(150,180,200,0.4)"/>
                  <line x1="80" y1="42" x2="120" y2="42"/>
                </>}
                {sel === 3 && <>
                  {[0,1,2,3].map(i => (
                    <g key={i} transform={`translate(${30 + i*40} 50)`}>
                      <line x1="0" y1="0" x2="40" y2="0" strokeWidth="1.5"/>
                      <polygon points="38,-4 44,0 38,4" fill="var(--tsp-ink)"/>
                      <path d="M 0 -3 L -4 0 L 0 3" strokeWidth="1.5"/>
                    </g>
                  ))}
                </>}
                {sel >= 4 && <>
                  <rect x="60" y="35" width="80" height="30" fill="rgba(20,24,30,0.08)"/>
                  <line x1="60" y1="50" x2="140" y2="50"/>
                </>}
              </g>
            </svg>
            <div className="t-hand" style={{ position: "absolute", bottom: 8, right: 12, fontSize: 14, color: "var(--tsp-slate)" }}>
              {recipes[sel].out}
            </div>
          </div>

          <div style={{ display: "flex", gap: 18 }}>
            {/* ingredients */}
            <div style={{ flex: 1.2 }}>
              <div className="t-label-sm" style={{ marginBottom: 8 }}>SERVE</div>
              {[
                { name: "Stracci puliti", need: 2, have: 4 },
                { name: "Acqua bollita",  need: 1, have: 1 },
              ].map((ing, i) => {
                const ok = ing.have >= ing.need;
                return (
                  <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", padding: "6px 0", borderBottom: "1px dashed rgba(20,24,30,0.2)" }}>
                    <span className="t-serif" style={{ fontSize: 15, color: ok ? "var(--tsp-ink)" : "var(--tsp-rust)" }}>{ing.name}</span>
                    <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span className="t-sans" style={{ fontSize: 11, letterSpacing: "0.12em", color: ok ? "var(--tsp-mint)" : "var(--tsp-rust)" }}>
                        {ing.have} / {ing.need}
                      </span>
                      {ok ? <span style={{ color: "var(--tsp-mint)" }}>✓</span> : <span style={{ color: "var(--tsp-rust)" }}>✗</span>}
                    </span>
                  </div>
                );
              })}
              {recipes[sel].missing && (
                <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-rust)", marginTop: 8 }}>
                  manca: {recipes[sel].missing}
                </div>
              )}
            </div>

            {/* check / time */}
            <div style={{ flex: 1 }}>
              <div className="t-label-sm" style={{ marginBottom: 8 }}>PROVA · COSTO</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <ResourceLine label="ABILITÀ" val="Sopravv. DC 12"/>
                <ResourceLine label="TEMPO" val="30 min"/>
                <ResourceLine label="POSTO" val="Tavolo da lavoro"/>
                <ResourceLine label="ESITO" val="Quasi certo" accent={false}/>
              </div>
            </div>
          </div>

          <hr className="ink-rule-dashed" style={{ margin: "18px 0 14px" }}/>

          <div style={{ display: "flex", gap: 10 }}>
            <div className="tsp-btn tsp-btn-ghost" style={{ flex: 1, textAlign: "center" }}>SMANTELLA</div>
            <div className="tsp-btn tsp-btn-rust" style={{ flex: 2, textAlign: "center", background: recipes[sel].have ? "var(--tsp-rust)" : "transparent", color: recipes[sel].have ? "var(--tsp-paper)" : "var(--tsp-slate)", opacity: recipes[sel].have ? 1 : 0.5 }}>
              {recipes[sel].have ? "↵ CREA" : "INGREDIENTI INSUFFICIENTI"}
            </div>
          </div>

          <div style={{ position: "absolute", bottom: 16, left: 36, right: 44, display: "flex", justifyContent: "space-between" }}>
            <span className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", opacity: 0.8 }}>"meglio averli che cercarli"</span>
            <span className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>— pag. 61 —</span>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Crafting });
