// CharacterCreation.jsx — single variant matching "Diario" direction

function CharacterCreation() {
  const [rolled, setRolled] = useState(true);
  const [chosenBg, setChosenBg] = useState("scavenger");
  const stats = { FOR: 12, DES: 14, COS: 11, INT: 13, SAG: 15, CAR: 9 };

  const backgrounds = [
    { id: "scavenger", name: "Scavenger", note: "+2 Cercare · −1 Persuasione",
      tag: "chi cerca, trova", desc: "Sai dove guardare. Trent'anni di rovine ti hanno insegnato cosa cercare sotto le macerie." },
    { id: "medico",    name: "Medico da Campo", note: "+2 Medicina · −1 Forza",
      tag: "non guarisci nessuno", desc: "Hai imparato a cucire ferite prima di imparare a leggere. Le bende durano di più, le malattie meno." },
    { id: "guerrigliero", name: "Guerrigliero", note: "+2 Furtività · −1 Carisma",
      tag: "il primo colpo è tuo", desc: "Ti muovi come un'ombra. I tuoi attacchi a sorpresa fanno più male — ma non sai parlare con le persone." },
    { id: "custode",   name: "Custode", note: "+1 Saggezza · +1 Carisma",
      tag: "la promessa del padre", desc: "Hai ascoltato a lungo. Le persone parlano con te e i ricordi del padre ti vengono in mente al momento giusto." },
  ];
  const bg = backgrounds.find(b => b.id === chosenBg);

  return (
    <div style={{ position: "relative", width: "100%", height: "100%", background: "#0e1115", overflow: "hidden" }}>
      <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(ellipse 60% 50% at 50% 40%, rgba(120,130,145,0.12), transparent 70%), linear-gradient(180deg, #181b21, #0e1115)"
      }}/>

      {/* book — two pages */}
      <div style={{
        position: "absolute", left: 24, right: 24, top: 24, bottom: 24,
        display: "flex",
        background: "var(--tsp-paper)",
        boxShadow: "0 30px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,0,0,0.4)"
      }}>
        <div style={{
          position: "absolute", left: "50%", top: 0, bottom: 0, width: 40,
          transform: "translateX(-50%)",
          background: "radial-gradient(ellipse 100% 100% at center, rgba(20,24,30,0.35), transparent 70%)",
          pointerEvents: "none", zIndex: 10
        }}/>
        <div style={{
          position: "absolute", left: "50%", top: 0, bottom: 0, width: 2,
          background: "rgba(20,24,30,0.55)", transform: "translateX(-50%)", zIndex: 11
        }}/>

        {/* LEFT — survivor sheet */}
        <div className="paper" style={{ flex: 1, padding: "32px 36px 32px 44px", position: "relative" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", borderBottom: "1.5px solid var(--tsp-ink)", paddingBottom: 8, marginBottom: 18 }}>
            <div>
              <div className="t-label">SCHEDA SOPRAVVISSUTO</div>
              <div className="t-serif" style={{ fontSize: 30, lineHeight: 1, fontWeight: 500 }}>Chi sei.</div>
            </div>
            <Stamp rotate={-4} color="rust" style={{ fontSize: 11, padding: "3px 8px 2px", borderWidth: 2 }}>NON COMPILATA</Stamp>
          </div>

          {/* name field */}
          <div style={{ marginBottom: 18 }}>
            <div className="t-label-sm" style={{ marginBottom: 4 }}>NOME</div>
            <div style={{ borderBottom: "1.5px solid var(--tsp-ink)", paddingBottom: 4, display: "flex", alignItems: "baseline", gap: 8 }}>
              <span className="t-serif" style={{ fontSize: 26, fontStyle: "italic" }}>Ultimo</span>
              <span style={{ width: 2, height: 24, background: "var(--tsp-ink)", animation: "blink 1s infinite" }}/>
            </div>
            <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", marginTop: 4 }}>
              "non è davvero il mio nome, ma lo è diventato"
            </div>
          </div>

          {/* portrait sketch */}
          <div style={{ display: "flex", gap: 16, marginBottom: 18 }}>
            <div className="tsp-photo" style={{ width: 120, aspectRatio: "4/5", border: "1.5px solid var(--tsp-ink)", flex: "0 0 auto" }}>
              <svg viewBox="0 0 100 125" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
                <rect width="100" height="125" fill="#2a3340"/>
                <circle cx="50" cy="46" r="22" fill="#3a4654"/>
                <path d="M 16 125 Q 50 78 84 125 Z" fill="#3a4654"/>
                <path d="M 36 43 L 34 56 M 64 43 L 66 56" stroke="#1a1d22" strokeWidth="1.2" fill="none"/>
                <path d="M 42 67 Q 50 72 58 67" stroke="#1a1d22" strokeWidth="1" fill="none"/>
              </svg>
            </div>
            <div style={{ flex: 1 }}>
              <div className="t-label-sm" style={{ marginBottom: 4 }}>ASPETTO</div>
              <div className="t-hand" style={{ fontSize: 15, color: "var(--tsp-ink)", lineHeight: 1.4 }}>
                cappotto grigio,<br/>
                cicatrice sulla guancia,<br/>
                occhi stanchi
              </div>
              <hr className="ink-rule-dashed" style={{ margin: "10px 0" }}/>
              <div className="t-label-sm" style={{ marginBottom: 4 }}>ETÀ</div>
              <div className="t-serif" style={{ fontSize: 18 }}>22 anni</div>
              <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)" }}>
                undici dopo la fine
              </div>
            </div>
          </div>

          {/* stats */}
          <hr className="ink-rule-dashed" style={{ marginBottom: 14 }}/>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 }}>
            <div className="t-label">ABILITÀ PRIMARIE</div>
            <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.2em", color: "var(--tsp-rust)", cursor: "pointer" }}>
              ↻ RILANCIA I DADI
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px 24px" }}>
            {Object.entries(stats).map(([k, v]) => {
              const mod = Math.floor((v - 10) / 2);
              return (
                <div key={k} style={{ display: "flex", alignItems: "center", gap: 12, borderBottom: "1px dotted rgba(20,24,30,0.3)", paddingBottom: 5 }}>
                  <span className="t-sans" style={{ fontSize: 11, letterSpacing: "0.2em", color: "var(--tsp-slate)", minWidth: 32 }}>{k}</span>
                  <span className="t-serif" style={{ fontSize: 22, fontWeight: 500 }}>{v}</span>
                  <span className="t-sans" style={{ fontSize: 11, letterSpacing: "0.1em", color: mod >= 0 ? "var(--tsp-mint)" : "var(--tsp-rust)" }}>
                    {mod >= 0 ? `+${mod}` : mod}
                  </span>
                  {/* dice */}
                  <div style={{ marginLeft: "auto", display: "flex", gap: 3 }}>
                    {[0,1,2].map(d => (
                      <div key={d} style={{
                        width: 14, height: 14, border: "1.5px solid var(--tsp-ink-faded)",
                        fontSize: 9, display: "flex", alignItems: "center", justifyContent: "center",
                        fontFamily: "var(--tsp-sans)", color: "var(--tsp-ink-faded)"
                      }}>{[1,3,5,6,4][d]}</div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          <div style={{ position: "absolute", bottom: 16, left: 44, right: 36 }} className="t-sans">
            <span style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>— pag. 1 — </span>
          </div>
        </div>

        {/* RIGHT — background + start */}
        <div className="paper" style={{ flex: 1, padding: "32px 44px 32px 36px", position: "relative" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", borderBottom: "1.5px solid var(--tsp-ink)", paddingBottom: 8, marginBottom: 18 }}>
            <div>
              <div className="t-label">DA DOVE VIENI</div>
              <div className="t-serif" style={{ fontSize: 30, lineHeight: 1, fontWeight: 500 }}>Cosa hai fatto, finora.</div>
            </div>
          </div>

          {/* background cards */}
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {backgrounds.map(b => {
              const active = b.id === chosenBg;
              return (
                <div
                  key={b.id}
                  onClick={() => setChosenBg(b.id)}
                  style={{
                    display: "flex", gap: 14,
                    padding: "12px 14px",
                    border: active ? "1.5px solid var(--tsp-rust)" : "1px solid rgba(20,24,30,0.3)",
                    background: active ? "rgba(125,58,42,0.06)" : "transparent",
                    cursor: "pointer"
                  }}
                >
                  <div style={{
                    width: 22, height: 22, flex: "0 0 auto",
                    border: "1.5px solid var(--tsp-ink)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    background: active ? "var(--tsp-ink)" : "transparent",
                    color: "var(--tsp-paper)", fontSize: 13
                  }}>{active ? "✓" : ""}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <span className="t-serif" style={{ fontSize: 19, fontWeight: 500 }}>{b.name}</span>
                      <span className="t-sans" style={{ fontSize: 10, letterSpacing: "0.18em", color: "var(--tsp-slate)" }}>{b.note}</span>
                    </div>
                    <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-rust)", marginTop: 1, opacity: 0.85 }}>
                      "{b.tag}"
                    </div>
                    {active && (
                      <p className="t-serif" style={{ fontSize: 13, lineHeight: 1.5, color: "var(--tsp-ink-faded)", marginTop: 6, fontStyle: "italic", textWrap: "pretty" }}>
                        {b.desc}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <hr className="ink-rule-dashed" style={{ margin: "20px 0 14px" }}/>

          {/* allegiance hint */}
          <div className="t-label-sm" style={{ marginBottom: 6 }}>BUSSOLA MORALE</div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span className="t-hand" style={{ fontSize: 15, color: "var(--tsp-mint)" }}>Lena</span>
            <div style={{ flex: 1, height: 6, background: "rgba(20,24,30,0.15)", position: "relative" }}>
              <div style={{ position: "absolute", left: "50%", top: -4, width: 2, height: 14, background: "var(--tsp-ink)", transform: "translateX(-50%)" }}/>
            </div>
            <span className="t-hand" style={{ fontSize: 15, color: "var(--tsp-rust)" }}>Elian</span>
          </div>
          <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.18em", color: "var(--tsp-slate-light)", marginTop: 6, textAlign: "center" }}>
            le tue scelte lo decideranno
          </div>

          {/* footer / start */}
          <div style={{ position: "absolute", bottom: 22, left: 36, right: 44, display: "flex", gap: 12 }}>
            <div className="tsp-btn tsp-btn-ghost" style={{ flex: 1, textAlign: "center" }}>← INDIETRO</div>
            <div className="tsp-btn tsp-btn-rust" style={{ flex: 2, textAlign: "center" }}>COMINCIA IL VIAGGIO</div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { CharacterCreation });
