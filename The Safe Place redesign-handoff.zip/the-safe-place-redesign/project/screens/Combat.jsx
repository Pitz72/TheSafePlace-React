// Combat.jsx — turn-based combat, atmospheric + journal-style

function Combat() {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden", background: "#0a0d12" }}>
      {/* atmospheric scene — forest night, enemy silhouette */}
      <svg viewBox="0 0 1280 800" preserveAspectRatio="xMidYMid slice"
           style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        <defs>
          <linearGradient id="cbtSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1a1f28"/>
            <stop offset="60%" stopColor="#2a3340"/>
            <stop offset="100%" stopColor="#0e1115"/>
          </linearGradient>
          <radialGradient id="cbtSpot" cx="50%" cy="42%" r="50%">
            <stop offset="0%" stopColor="rgba(232,234,237,0.18)"/>
            <stop offset="100%" stopColor="rgba(0,0,0,0)"/>
          </radialGradient>
        </defs>
        <rect width="1280" height="800" fill="url(#cbtSky)"/>
        <rect width="1280" height="800" fill="url(#cbtSpot)"/>
        {/* mist layers */}
        <rect y="500" width="1280" height="300" fill="rgba(120,130,145,0.12)"/>
        {/* trees silhouette */}
        <g fill="#0a0d12">
          {[60, 180, 240, 380, 520, 640, 820, 960, 1080, 1200].map((x, i) => (
            <g key={i}>
              <rect x={x-4} y={400+(i%3)*20} width="8" height={200}/>
              <polygon points={`${x-26},${430+(i%3)*20} ${x},${380+(i%3)*20} ${x+26},${430+(i%3)*20}`}/>
              <polygon points={`${x-20},${460+(i%3)*20} ${x},${410+(i%3)*20} ${x+20},${460+(i%3)*20}`}/>
            </g>
          ))}
        </g>
        {/* enemy silhouette center-distance */}
        <g transform="translate(640 460)" fill="#161a22">
          <ellipse cx="0" cy="-32" rx="20" ry="24"/>
          <path d="M -22 -16 L 22 -16 L 18 80 L -18 80 Z"/>
          {/* shoulders / hood */}
          <path d="M -32 -12 L -22 -16 L -22 -6 Z M 32 -12 L 22 -16 L 22 -6 Z"/>
          {/* arm holding weapon */}
          <path d="M -16 8 L -36 60 L -30 70 L -8 22 Z"/>
          <line x1="-36" y1="60" x2="-58" y2="20" stroke="#161a22" strokeWidth="3"/>
          {/* eye glow */}
          <circle cx="-6" cy="-34" r="2" fill="#8a3a2a" opacity="0.9"/>
          <circle cx="6" cy="-34" r="2" fill="#8a3a2a" opacity="0.9"/>
        </g>
        {/* foreground darkness */}
        <rect y="600" width="1280" height="200" fill="rgba(0,0,0,0.55)"/>
      </svg>

      {/* grain */}
      <div style={{
        position: "absolute", inset: 0, opacity: 0.22, pointerEvents: "none",
        backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence baseFrequency='0.85' numOctaves='2'/></filter><rect width='300' height='300' filter='url(%23n)'/></svg>\")",
        mixBlendMode: "overlay"
      }}/>

      {/* TOP — combat status strip */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0,
        padding: "16px 28px",
        background: "linear-gradient(180deg, rgba(20,24,32,0.85), rgba(20,24,32,0.0))",
        color: "var(--tsp-paper)",
        display: "flex", justifyContent: "space-between", alignItems: "center"
      }}>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.4em", opacity: 0.55 }}>
          COMBATTIMENTO · TURNO 3
        </div>
        <div style={{ textAlign: "center" }}>
          <div className="t-hand" style={{ fontSize: 18, color: "var(--tsp-rust)" }}>nessuna via di fuga</div>
        </div>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.4em", opacity: 0.55 }}>
          INIZIATIVA · TUO
        </div>
      </div>

      {/* enemy card — pinned top-center, like a "field note" */}
      <div className="paper" style={{
        position: "absolute", left: "50%", top: 70,
        transform: "translateX(-50%) rotate(-1deg)",
        width: 360, padding: "16px 18px 14px",
        boxShadow: "0 16px 32px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,0,0,0.4)"
      }}>
        <Tape top={-10} left={130} w={100} h={20} rot={2}/>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <div className="t-label" style={{ color: "var(--tsp-rust)" }}>NEMICO · ANALIZZATO</div>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.18em", color: "var(--tsp-slate)" }}>ELITE</div>
        </div>
        <div className="t-serif" style={{ fontSize: 22, lineHeight: 1, marginTop: 6, fontWeight: 500 }}>
          Capo Predone Veterano
        </div>
        <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", marginTop: 2 }}>
          armatura tattica · machete arrugginito
        </div>
        <hr className="ink-rule-dashed" style={{ margin: "10px 0 8px" }}/>

        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <StatMeter label="VITA" value={38} max={50} color="rust"/>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11 }}>
            <span className="t-sans" style={{ letterSpacing: "0.18em", color: "var(--tsp-slate)" }}>AC</span>
            <span className="t-serif">16</span>
            <span className="t-sans" style={{ letterSpacing: "0.18em", color: "var(--tsp-slate)" }}>· DEB.</span>
            <span className="t-serif" style={{ color: "var(--tsp-rust)" }}>FIANCO SINISTRO</span>
          </div>
        </div>

        <hr className="ink-rule-dashed" style={{ margin: "8px 0" }}/>
        <div className="t-label-sm" style={{ color: "var(--tsp-rust)", marginBottom: 3 }}>OSSERVAZIONE</div>
        <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-ink)", lineHeight: 1.35 }}>
          "se manco il colpo, contrattacca.<br/>
          la finta elaborata DC 16 lo confonde."
        </div>
      </div>

      {/* LEFT — your status, small pinned card */}
      <div className="paper" style={{
        position: "absolute", left: 24, top: 220, width: 220,
        padding: "14px 16px",
        transform: "rotate(-1.5deg)",
        boxShadow: "0 12px 24px rgba(0,0,0,0.55)"
      }}>
        <Pin top={-7} left={100} variant="rust"/>
        <div className="t-label">TU · ULTIMO</div>
        <hr className="ink-rule" style={{ margin: "6px 0 10px" }}/>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <StatMeter label="VITA"   value={42} max={100} color="rust"  compact/>
          <StatMeter label="FATICA" value={82} max={100} color="ink"   compact/>
        </div>
        <hr className="ink-rule-dashed" style={{ margin: "10px 0 8px" }}/>
        <div className="t-label-sm" style={{ marginBottom: 4 }}>EQUIPAGGIATO</div>
        <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-ink)", lineHeight: 1.4 }}>
          · coltello da campo<br/>
          · pistola 9mm (5)<br/>
          · giubb. consunto
        </div>
        <hr className="ink-rule-dashed" style={{ margin: "10px 0 6px" }}/>
        <div className="t-label-sm" style={{ marginBottom: 4 }}>STATO</div>
        <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-rust)" }}>· ferito (gamba)</div>
      </div>

      {/* RIGHT — combat log */}
      <div className="paper" style={{
        position: "absolute", right: 24, top: 220, width: 260,
        padding: "14px 16px",
        transform: "rotate(1deg)",
        boxShadow: "0 12px 24px rgba(0,0,0,0.55)",
        maxHeight: 340, overflow: "hidden"
      }}>
        <Tape top={-10} right={90} w={70} h={18} rot={-3}/>
        <div className="t-label">REGISTRO</div>
        <hr className="ink-rule" style={{ margin: "6px 0 10px" }}/>
        <div style={{ display: "flex", flexDirection: "column", gap: 4, fontSize: 12 }}>
          <JournalEntry time="T-3">Hai analizzato il nemico. Hai notato il fianco sinistro scoperto.</JournalEntry>
          <JournalEntry time="T-2" tone="rust">Il Veterano ha colpito di taglio. <strong>−14 VITA</strong>.</JournalEntry>
          <JournalEntry time="T-2">Hai sparato con la 9mm. Tiro 14 vs AC 16. <strong>MANCATO</strong>.</JournalEntry>
          <JournalEntry time="T-1" tone="rust">Contrattacco. <strong>−10 VITA</strong>.</JournalEntry>
          <JournalEntry time="T-1" tone="mint">Hai cercato copertura. +4 AC per 2 turni.</JournalEntry>
        </div>
      </div>

      {/* BOTTOM — action cards (hand of choices) */}
      <div style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        padding: "20px 32px 28px",
        display: "flex", justifyContent: "center", gap: 14
      }}>
        {[
          { k: "1", title: "Attacca", sub: "coltello · 1d6+2", tag: "DES vs AC 16", color: "rust" },
          { k: "2", title: "Spara", sub: "9mm · 5 colpi", tag: "tiro 1d20+3", color: "rust" },
          { k: "3", title: "Finta elaborata", sub: "Inganno DC 16", tag: "annulla contrattacco", color: "mint" },
          { k: "4", title: "Mira al fianco", sub: "danno bonus +1d6", tag: "DEB. SCOPERTA", color: "rust" },
          { k: "5", title: "Cerca copertura", sub: "Percezione DC 12", tag: "+4 AC · 2 turni", color: "slate" },
          { k: "6", title: "Fuggi", sub: "Atletica DC 14", tag: "rischio", color: "ink" },
        ].map((a) => {
          const c = a.color === "rust" ? "var(--tsp-rust)" :
                    a.color === "mint" ? "var(--tsp-mint)" :
                    a.color === "slate" ? "var(--tsp-slate)" :
                    "var(--tsp-ink-faded)";
          return (
            <div key={a.k} style={{
              width: 170, padding: "12px 14px 10px",
              background: "var(--tsp-paper)",
              border: `1.5px solid ${c}`,
              boxShadow: "0 14px 24px rgba(0,0,0,0.6)",
              transform: `rotate(${(parseInt(a.k) - 3.5) * 0.6}deg) translateY(${Math.abs(parseInt(a.k) - 3.5) * 2}px)`,
              cursor: "pointer", position: "relative"
            }}>
              <div className="t-sans" style={{
                position: "absolute", top: 8, left: 10, fontSize: 10,
                width: 16, height: 16, lineHeight: "16px", textAlign: "center",
                border: `1px solid ${c}`, color: c, fontWeight: 600
              }}>{a.k}</div>
              <div className="t-serif" style={{ fontSize: 18, fontWeight: 500, lineHeight: 1.1, marginTop: 16, color: "var(--tsp-ink)" }}>
                {a.title}
              </div>
              <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", marginTop: 4 }}>
                {a.sub}
              </div>
              <hr className="ink-rule-dashed" style={{ margin: "8px 0 6px" }}/>
              <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.2em", color: c }}>
                {a.tag}
              </div>
            </div>
          );
        })}
      </div>

      {/* small hint at bottom */}
      <div style={{ position: "absolute", bottom: 4, left: 0, right: 0, textAlign: "center" }}>
        <span className="t-sans" style={{ fontSize: 9, letterSpacing: "0.4em", color: "rgba(216,210,194,0.45)" }}>
          1–6 SCEGLI · ↵ CONFERMA · I INVENTARIO · ESC FUGGI
        </span>
      </div>
    </div>
  );
}

Object.assign(window, { Combat });
