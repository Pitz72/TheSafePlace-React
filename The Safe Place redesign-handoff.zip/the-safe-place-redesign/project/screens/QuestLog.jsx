// QuestLog.jsx — 2 variants
// A: "Bacheca" — corkboard with pinned quest notes
// B: "Indice" — book-style quest log with archive

const QUESTS = [
  {
    id: "main",
    type: "MAIN",
    title: "Il Segnale del Padre",
    chapter: "Echo III · Le Spine",
    stage: 2, total: 7,
    desc: "Hai trovato la lettera bagnata. Il padre parla di un segnale a nord, oltre Le Spine. Devi raggiungere la torre radio prima della prossima tempesta.",
    next: "Raggiungere la torre radio · 4.2 km a nord-est",
    color: "rust"
  },
  {
    id: "q1",
    type: "SUB",
    title: "La Pompa Silenziosa",
    chapter: "Vecchia Città",
    stage: 1, total: 3,
    desc: "Olivia ha bisogno di pezzi per riparare la pompa d'acqua del villaggio. Ti ha chiesto un filtro industriale.",
    next: "Trovare 1 × Filtro Industriale",
    color: "ink"
  },
  {
    id: "q2",
    type: "SUB",
    title: "I Segni della Cenere",
    chapter: "Forest dei Sospiri",
    stage: 2, total: 4,
    desc: "L'Eremita parla di un rituale antico. Hai trovato due dei tre siti — manca il Cerchio Rituale.",
    next: "Trovare il Cerchio Rituale",
    color: "ink"
  },
  {
    id: "q3",
    type: "SUB",
    title: "Cinghiali a Nord",
    chapter: "Bounty · Silas",
    stage: 1, total: 1,
    desc: "Silas paga in munizioni chi gli porta prove di tre cinghiali abbattuti.",
    next: "Uccidere cinghiali · 0 / 3",
    color: "slate"
  },
  {
    id: "q4",
    type: "SUB",
    title: "Il Debito del Sopravvissuto",
    chapter: "Crocevia",
    stage: 3, total: 3,
    desc: "Hai salvato Liam dai predoni. Ora devi scortare sua sorella Elara al sicuro.",
    next: "Scortare Elara al Crocevia",
    color: "mint"
  },
];

const COMPLETED = [
  "Il Talismano Perduto",
  "Il Messaggio del Fiume",
  "Indagine al Crocevia",
  "L'Ultimo Messaggero",
  "La Donna che Attende",
];

const LORE = [
  { name: "Progetto Eco", desc: "Interfaccia neurale collettiva" },
  { name: "Progetto Rinascita", desc: "Tessuto della Cenere" },
  { name: "Clan Corvo", desc: "Sopravvissuti delle catene" },
];

// ====================================================================
// VARIANT A — Bacheca (corkboard, pinned quest notes)
// ====================================================================
function QuestLogA() {
  const [selected, setSelected] = useState("main");
  const sel = QUESTS.find(q => q.id === selected) || QUESTS[0];

  return (
    <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden" }}>
      {/* dark cork desk */}
      <div style={{
        position: "absolute", inset: 0,
        background: `radial-gradient(ellipse 80% 60% at 50% 50%, #2a2620, #14110d 100%)`
      }}/>
      <div style={{
        position: "absolute", inset: 0, opacity: 0.18, pointerEvents: "none",
        backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='400' height='400'><filter id='n'><feTurbulence baseFrequency='1.2' numOctaves='2' seed='9'/></filter><rect width='400' height='400' filter='url(%23n)'/></svg>\")",
        mixBlendMode: "overlay"
      }}/>

      {/* header strip */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0,
        padding: "20px 32px",
        display: "flex", justifyContent: "space-between", alignItems: "center",
        color: "var(--tsp-paper)"
      }}>
        <div>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.4em", opacity: 0.55, marginBottom: 4 }}>
            DIARIO DELLE QUEST
          </div>
          <div className="t-serif" style={{ fontSize: 28, lineHeight: 1 }}>
            Cosa devo fare
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.32em", opacity: 0.55 }}>
            5 ATTIVE · 5 COMPLETATE · 3 SCOPERTE
          </div>
          <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-mint)", marginTop: 2, opacity: 0.85 }}>
            "tieni il filo, non perderlo"
          </div>
        </div>
      </div>

      {/* MAIN QUEST card - large, central-left */}
      <div
        onClick={() => setSelected("main")}
        style={{
          position: "absolute", left: 50, top: 100, width: 380,
          background: "var(--tsp-paper)",
          padding: "20px 22px 18px",
          transform: "rotate(-1.5deg)",
          boxShadow: "0 16px 32px rgba(0,0,0,0.65)",
          cursor: "pointer",
          outline: selected === "main" ? "2px solid var(--tsp-rust)" : "none",
          outlineOffset: 4
        }}
      >
        <Pin top={-7} left={170} variant="rust"/>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
          <Stamp rotate={-3} color="rust">MAIN</Stamp>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.24em", color: "var(--tsp-slate)", textAlign: "right" }}>
            STAGE 2 / 7
          </div>
        </div>
        <div className="t-serif" style={{ fontSize: 28, lineHeight: 1, marginTop: 12 }}>
          {QUESTS[0].title}
        </div>
        <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", marginTop: 4 }}>
          {QUESTS[0].chapter}
        </div>
        <hr className="ink-rule-dashed" style={{ margin: "14px 0 12px" }}/>
        <p className="t-serif" style={{ fontSize: 14, lineHeight: 1.5, color: "var(--tsp-ink-faded)", fontStyle: "italic", textWrap: "pretty" }}>
          {QUESTS[0].desc}
        </p>
        <div style={{ marginTop: 12, padding: "10px 12px", background: "rgba(125,58,42,0.08)", borderLeft: "2px solid var(--tsp-rust)" }}>
          <div className="t-label-sm" style={{ color: "var(--tsp-rust)", marginBottom: 3 }}>PROSSIMO PASSO</div>
          <div className="t-serif" style={{ fontSize: 14 }}>{QUESTS[0].next}</div>
        </div>

        {/* progress dots */}
        <div style={{ marginTop: 14, display: "flex", gap: 6, alignItems: "center" }}>
          {Array.from({ length: 7 }).map((_, i) => (
            <div key={i} style={{
              width: 10, height: 10, borderRadius: "50%",
              border: "1.5px solid var(--tsp-ink)",
              background: i < 2 ? "var(--tsp-rust)" : "transparent"
            }}/>
          ))}
        </div>
      </div>

      {/* sub-quest notes scattered */}
      {QUESTS.slice(1).map((q, i) => {
        const positions = [
          { left: 460, top: 110, rot: 2, w: 230 },
          { left: 720, top: 140, rot: -3, w: 230 },
          { left: 460, top: 360, rot: 1.5, w: 230 },
          { left: 720, top: 380, rot: -1.5, w: 230 },
        ];
        const p = positions[i] || positions[0];
        const active = selected === q.id;
        return (
          <div
            key={q.id}
            onClick={() => setSelected(q.id)}
            style={{
              position: "absolute",
              left: p.left, top: p.top, width: p.w,
              background: "#cfc8b6",
              padding: "12px 14px 10px",
              transform: `rotate(${p.rot}deg)`,
              boxShadow: "0 10px 22px rgba(0,0,0,0.55)",
              cursor: "pointer",
              outline: active ? "2px solid var(--tsp-rust)" : "none",
              outlineOffset: 4
            }}
          >
            <Pin top={-7} left={p.w / 2 - 7} variant={q.color === "mint" ? "mint" : q.color === "rust" ? "rust" : "ink"}/>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <div className="t-label-sm">SUB</div>
              <div className="t-sans" style={{ fontSize: 9, color: "var(--tsp-slate-light)", letterSpacing: "0.16em" }}>
                {q.stage}/{q.total}
              </div>
            </div>
            <div className="t-serif" style={{ fontSize: 17, fontWeight: 500, lineHeight: 1.1, marginTop: 6 }}>
              {q.title}
            </div>
            <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", marginTop: 4, lineHeight: 1.3 }}>
              {q.next}
            </div>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.18em", color: "var(--tsp-slate)", marginTop: 8 }}>
              {q.chapter.toUpperCase()}
            </div>
          </div>
        );
      })}

      {/* completed list — small notepad */}
      <div style={{
        position: "absolute", left: 50, bottom: 50, width: 240,
        background: "#bdb8a5",
        padding: "12px 14px 10px",
        transform: "rotate(2deg)",
        boxShadow: "0 10px 22px rgba(0,0,0,0.55)"
      }}>
        <Tape top={-10} left={90} w={60} h={18} rot={-4}/>
        <div className="t-label-sm" style={{ marginBottom: 6 }}>COMPLETATE</div>
        {COMPLETED.map((c, i) => (
          <div key={i} className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", lineHeight: 1.4, textDecoration: "line-through", textDecorationColor: "var(--tsp-rust)" }}>
            {c}
          </div>
        ))}
      </div>

      {/* lore archive — small pinned card right */}
      <div style={{
        position: "absolute", right: 50, bottom: 70, width: 240,
        background: "var(--tsp-paper)",
        padding: "14px 16px 12px",
        transform: "rotate(-2deg)",
        boxShadow: "0 12px 24px rgba(0,0,0,0.55)"
      }}>
        <Pin top={-7} left={114} variant="bone"/>
        <div className="t-label-sm" style={{ color: "var(--tsp-mint)", marginBottom: 6 }}>ARCHIVIO LORE · 3</div>
        {LORE.map((l, i) => (
          <div key={i} style={{ padding: "6px 0", borderBottom: i < LORE.length - 1 ? "1px dashed rgba(20,24,30,0.25)" : "none" }}>
            <div className="t-serif" style={{ fontSize: 14, fontStyle: "italic" }}>{l.name}</div>
            <div className="t-sans" style={{ fontSize: 10, color: "var(--tsp-slate-light)", letterSpacing: "0.12em" }}>
              {l.desc}
            </div>
          </div>
        ))}
      </div>

      {/* footer */}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "14px 32px", display: "flex", justifyContent: "space-between" }}>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.32em", color: "rgba(216,210,194,0.6)" }}>
          ↑ ↓ ← → NAVIGA · ↵ ESPANDI · TAB ARCHIVIO · ESC CHIUDI
        </div>
      </div>
    </div>
  );
}

// ====================================================================
// VARIANT B — Indice (book-style log, double-page)
// ====================================================================
function QuestLogB() {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", background: "#0e1115", overflow: "hidden" }}>
      <div style={{
        position: "absolute", inset: 0,
        background: `radial-gradient(ellipse 60% 50% at 50% 40%, rgba(120,130,145,0.12), transparent 70%), linear-gradient(180deg, #181b21, #0e1115)`
      }}/>

      {/* book — two pages */}
      <div style={{
        position: "absolute",
        left: 24, right: 24, top: 24, bottom: 24,
        display: "flex",
        background: "var(--tsp-paper)",
        boxShadow: "0 30px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,0,0,0.4)"
      }}>
        <div style={{
          position: "absolute", left: "50%", top: 0, bottom: 0, width: 40,
          transform: "translateX(-50%)",
          background: "radial-gradient(ellipse 100% 100% at center, rgba(20,24,30,0.35), transparent 70%)",
          pointerEvents: "none", zIndex: 10
        }}/>
        <div style={{
          position: "absolute", left: "50%", top: 0, bottom: 0, width: 2,
          background: "rgba(20,24,30,0.55)",
          transform: "translateX(-50%)",
          zIndex: 11
        }}/>

        {/* LEFT PAGE — index of quests */}
        <div className="paper" style={{ flex: 1, padding: "32px 36px 32px 44px", position: "relative" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", borderBottom: "1.5px solid var(--tsp-ink)", paddingBottom: 8, marginBottom: 16 }}>
            <div>
              <div className="t-label">REGISTRO</div>
              <div className="t-serif" style={{ fontSize: 28, fontWeight: 500, lineHeight: 1 }}>Cosa devo fare</div>
            </div>
            <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)" }}>
              5 attive · 5 finite
            </div>
          </div>

          {/* main quest highlighted */}
          <div style={{
            padding: "14px 16px",
            background: "rgba(125,58,42,0.08)",
            borderLeft: "3px solid var(--tsp-rust)",
            marginBottom: 14
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <div className="t-label" style={{ color: "var(--tsp-rust)" }}>STORIA PRINCIPALE</div>
              <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.18em", color: "var(--tsp-slate)" }}>
                STAGE {QUESTS[0].stage}/{QUESTS[0].total}
              </div>
            </div>
            <div className="t-serif" style={{ fontSize: 22, marginTop: 6, fontWeight: 500 }}>
              {QUESTS[0].title}
            </div>
            <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", marginTop: 2 }}>
              {QUESTS[0].chapter}
            </div>
            <p className="t-serif" style={{ fontSize: 14, lineHeight: 1.5, color: "var(--tsp-ink-faded)", fontStyle: "italic", marginTop: 8, textWrap: "pretty" }}>
              "{QUESTS[0].next}"
            </p>
          </div>

          {/* sub quests */}
          <div className="t-label-sm" style={{ marginBottom: 8 }}>SECONDARIE</div>
          <div>
            {QUESTS.slice(1).map((q, i) => {
              const dot = q.color === "rust" ? "var(--tsp-rust)" :
                          q.color === "mint" ? "var(--tsp-mint)" :
                          q.color === "slate" ? "var(--tsp-slate)" :
                          "var(--tsp-ink)";
              return (
                <div key={q.id} style={{
                  display: "flex", alignItems: "baseline", gap: 12,
                  padding: "10px 0",
                  borderBottom: "1px dashed rgba(20,24,30,0.22)"
                }}>
                  <span style={{ width: 7, height: 7, borderRadius: "50%", background: dot, flex: "0 0 auto" }}/>
                  <div style={{ flex: 1 }}>
                    <div className="t-serif" style={{ fontSize: 16, lineHeight: 1.2 }}>{q.title}</div>
                    <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", marginTop: 1 }}>
                      {q.next}
                    </div>
                  </div>
                  <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.18em", color: "var(--tsp-slate-light)", flex: "0 0 auto" }}>
                    {q.stage}/{q.total}
                  </div>
                </div>
              );
            })}
          </div>

          <div style={{ position: "absolute", bottom: 16, left: 44, right: 36, display: "flex", justifyContent: "space-between" }}>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>— pag. 51 —</div>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>↑ ↓ NAVIGA · TAB COMPLETATE</div>
          </div>
        </div>

        {/* RIGHT PAGE — detail of selected quest */}
        <div className="paper" style={{ flex: 1, padding: "32px 44px 32px 36px", position: "relative" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", borderBottom: "1.5px solid var(--tsp-ink)", paddingBottom: 8, marginBottom: 14 }}>
            <div className="t-label">DETTAGLIO</div>
            <Stamp rotate={-3} color="rust" style={{ fontSize: 11, padding: "3px 8px 2px", borderWidth: 2 }}>MAIN · ECHO III</Stamp>
          </div>

          <div className="t-serif" style={{ fontSize: 32, lineHeight: 1, fontWeight: 500, marginBottom: 4 }}>
            {QUESTS[0].title}
          </div>
          <div className="t-hand" style={{ fontSize: 16, color: "var(--tsp-slate)", marginBottom: 14 }}>
            {QUESTS[0].chapter}
          </div>

          <p className="t-serif" style={{ fontSize: 15, lineHeight: 1.6, color: "var(--tsp-ink)", marginBottom: 18, textWrap: "pretty" }}>
            {QUESTS[0].desc}
          </p>

          <hr className="ink-rule-dashed" style={{ marginBottom: 14 }}/>

          {/* stage list */}
          <div className="t-label-sm" style={{ marginBottom: 10 }}>FASI</div>
          {[
            { d: "Leggere la lettera bagnata", done: true },
            { d: "Decifrare le coordinate del padre", done: true },
            { d: "Raggiungere la torre radio · 4.2 km NE", done: false, active: true },
            { d: "Riparare il segnale (filtro · batteria · manuale)", done: false },
            { d: "Ascoltare la trasmissione", done: false },
            { d: "Seguire il segnale verso il rifugio", done: false },
            { d: "—", done: false, secret: true },
          ].map((s, i) => (
            <div key={i} style={{ display: "flex", gap: 12, alignItems: "baseline", padding: "6px 0" }}>
              <div style={{
                width: 16, height: 16, flex: "0 0 auto",
                border: "1.5px solid var(--tsp-ink)",
                background: s.done ? "var(--tsp-ink)" : "transparent",
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "var(--tsp-paper)", fontSize: 11
              }}>
                {s.done ? "✓" : s.active ? <span style={{ width: 6, height: 6, background: "var(--tsp-rust)", borderRadius: "50%" }}/> : null}
              </div>
              <div className="t-serif" style={{
                fontSize: 14, lineHeight: 1.4,
                color: s.done ? "var(--tsp-slate)" : s.active ? "var(--tsp-rust)" : "var(--tsp-ink)",
                textDecoration: s.done ? "line-through" : "none",
                fontStyle: s.secret ? "italic" : "normal",
                opacity: s.secret ? 0.5 : 1
              }}>
                {s.d}
              </div>
            </div>
          ))}

          <hr className="ink-rule-dashed" style={{ margin: "16px 0" }}/>

          <div style={{ display: "flex", gap: 24 }}>
            <div style={{ flex: 1 }}>
              <div className="t-label-sm" style={{ marginBottom: 6 }}>RICOMPENSA</div>
              <div className="t-serif" style={{ fontSize: 14, lineHeight: 1.5 }}>
                · 500 XP<br/>
                · Saggezza +1<br/>
                · "Verità sul padre"
              </div>
            </div>
            <div style={{ flex: 1 }}>
              <div className="t-label-sm" style={{ marginBottom: 6 }}>PERICOLI</div>
              <div className="t-hand" style={{ fontSize: 15, color: "var(--tsp-rust)", lineHeight: 1.3 }}>
                tempesta in arrivo,<br/>angeli della cenere
              </div>
            </div>
          </div>

          <div style={{ position: "absolute", bottom: 16, left: 36, right: 44, display: "flex", justifyContent: "space-between" }}>
            <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", opacity: 0.85 }}>
              "non guardare indietro"
            </div>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>— pag. 52 —</div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { QuestLogA, QuestLogB });
