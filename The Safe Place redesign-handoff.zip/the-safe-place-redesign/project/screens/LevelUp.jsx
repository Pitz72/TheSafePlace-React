// LevelUp.jsx — choosing a talent

function LevelUp() {
  const [chosen, setChosen] = useState(1);
  const talents = [
    { name: "Mano Ferma",     branch: "Combattimento", desc: "Tiri di pistola e armi a una mano in vantaggio quando il bersaglio è a meno di 6 metri.",
      effect: "ARMI · +2 attacco entro 6m", flavor: "\"Avvicinati. Mira al respiro, non al cuore.\"" },
    { name: "Occhio della Vecchia Città", branch: "Scavenger", desc: "Trovi un oggetto extra ogni volta che cerchi attivamente in un'area urbana. Le ricette comuni costano la metà.",
      effect: "CERCA · +1 oggetto in città", flavor: "\"Le rovine sono dispense, per chi sa guardare.\"" },
    { name: "Il Ricordo di Lena", branch: "Bussola morale", desc: "Quando l'allineamento è verso Lena, la Sazietà e l'Acqua scendono il 25% più lentamente.",
      effect: "COMPASSIONE · sopravvivenza migliorata", flavor: "\"Ti diceva: 'non mangiare da solo, mai'.\"" },
    { name: "Lingua di Marcus", branch: "Sociale",       desc: "Persuasione +2. Sblocchi sempre l'opzione di dialogo nascosta nei mercanti.",
      effect: "PERSUASIONE +2 · sconto baratto", flavor: "\"Le parole giuste valgono più di una pistola.\"" },
    { name: "Cammino Silente", branch: "Furtività",      desc: "Furtività +2. Il primo attacco da invisibile infligge danno doppio.",
      effect: "FURTIVITÀ +2 · primo colpo ×2", flavor: "\"Cammina come se la terra ti deve qualcosa.\"" },
    { name: "Cuore del Custode", branch: "Resistenza",   desc: "Vita massima +12. Recuperi 1 PF in più al risveglio.",
      effect: "VITA MAX +12 · rigen. potenziata", flavor: "\"Hai ereditato il petto di tuo padre. Usalo.\"" },
  ];
  const sel = talents[chosen];

  return (
    <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden",
      background: "radial-gradient(ellipse 60% 50% at 50% 50%, #1a1d22, #0a0d12)"
    }}>
      {/* atmospheric dust */}
      {Array.from({ length: 18 }).map((_, i) => (
        <div key={i} style={{
          position: "absolute", width: 1 + (i%2), height: 1 + (i%2),
          left: `${(i*37)%100}%`, top: `${(i*23)%100}%`,
          background: "rgba(220,228,235,0.35)", borderRadius: "50%"
        }}/>
      ))}

      {/* header */}
      <div style={{ position: "absolute", top: 36, left: 0, right: 0, textAlign: "center", color: "var(--tsp-paper)" }}>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.5em", opacity: 0.55, marginBottom: 8 }}>
          HAI RAGGIUNTO LIVELLO 5
        </div>
        <div className="t-serif" style={{ fontSize: 42, lineHeight: 1, fontWeight: 500, letterSpacing: "-0.005em" }}>
          Una nuova lezione.
        </div>
        <div className="t-hand" style={{ fontSize: 18, color: "var(--tsp-mint)", marginTop: 8, opacity: 0.9 }}>
          "ogni giorno che cammini, qualcosa impari"
        </div>
      </div>

      {/* main grid of talent cards */}
      <div style={{
        position: "absolute", left: 60, right: 60, top: 180,
        display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 18
      }}>
        {talents.map((t, i) => {
          const active = i === chosen;
          return (
            <div key={i}
              onClick={() => setChosen(i)}
              style={{
                background: "var(--tsp-paper)",
                padding: "18px 18px 14px",
                transform: `rotate(${active ? 0 : (i%2===0 ? -1.2 : 1.2)}deg) translateY(${active ? -4 : 0}px)`,
                boxShadow: active
                  ? "0 24px 40px rgba(0,0,0,0.7), 0 0 0 2px var(--tsp-rust)"
                  : "0 14px 22px rgba(0,0,0,0.5)",
                cursor: "pointer",
                position: "relative",
                transition: "transform 0.2s ease, box-shadow 0.2s ease"
              }}
              className="paper"
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                <div className="t-label-sm">{t.branch.toUpperCase()}</div>
                {active && <Stamp rotate={-3} color="rust" style={{ fontSize: 9, padding: "2px 6px", borderWidth: 2 }}>SCELTO</Stamp>}
              </div>
              <div className="t-serif" style={{ fontSize: 22, lineHeight: 1.05, fontWeight: 500, marginTop: 6, marginBottom: 8 }}>
                {t.name}
              </div>
              <hr className="ink-rule-dashed" style={{ marginBottom: 8 }}/>
              <p className="t-serif" style={{ fontSize: 13, lineHeight: 1.45, color: "var(--tsp-ink-faded)", marginBottom: 10, textWrap: "pretty" }}>
                {t.desc}
              </p>
              <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.22em", color: "var(--tsp-rust)", marginBottom: 6 }}>
                {t.effect}
              </div>
              <hr className="ink-rule-dashed" style={{ marginBottom: 6 }}/>
              <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", lineHeight: 1.3 }}>
                {t.flavor}
              </div>
            </div>
          );
        })}
      </div>

      {/* footer — confirm */}
      <div style={{ position: "absolute", bottom: 40, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 16 }}>
        <div className="tsp-btn tsp-btn-ghost" style={{ color: "var(--tsp-paper-edge)", borderColor: "transparent" }}>
          ↑ ↓ ← → SCEGLI
        </div>
        <div className="tsp-btn tsp-btn-rust" style={{ background: "var(--tsp-rust)", color: "var(--tsp-paper)", padding: "12px 32px 10px" }}>
          IMPARA "{sel.name.toUpperCase()}"
        </div>
      </div>

      {/* xp note bottom */}
      <div style={{ position: "absolute", bottom: 12, left: 0, right: 0, textAlign: "center" }}>
        <span className="t-sans" style={{ fontSize: 9, letterSpacing: "0.4em", color: "rgba(216,210,194,0.45)" }}>
          500 / 500 XP · PROSSIMO LIVELLO A 800 XP
        </span>
      </div>
    </div>
  );
}

Object.assign(window, { LevelUp });
