// Dialogue.jsx — conversation with NPC, journal-style

function Dialogue() {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden", background: "#0a0d12" }}>
      {/* atmospheric backdrop — inside an outpost */}
      <svg viewBox="0 0 1280 800" preserveAspectRatio="xMidYMid slice"
           style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.55 }}>
        <defs>
          <radialGradient id="dlgGlow" cx="60%" cy="35%" r="60%">
            <stop offset="0%" stopColor="rgba(232,210,170,0.20)"/>
            <stop offset="100%" stopColor="rgba(0,0,0,0)"/>
          </radialGradient>
        </defs>
        <rect width="1280" height="800" fill="#161a22"/>
        <rect width="1280" height="800" fill="url(#dlgGlow)"/>
        {/* lantern light pool on floor */}
        <ellipse cx="700" cy="700" rx="500" ry="120" fill="rgba(232,210,170,0.10)"/>
        {/* wooden boards on floor */}
        <g opacity="0.4">
          {Array.from({ length: 6 }).map((_, i) => (
            <line key={i} x1={0} y1={600 + i*40} x2="1280" y2={600 + i*40} stroke="#3a2a1a" strokeWidth="1"/>
          ))}
        </g>
        {/* hanging lantern */}
        <g transform="translate(960 110)">
          <line x1="0" y1="-110" x2="0" y2="0" stroke="#1a1d22" strokeWidth="1"/>
          <rect x="-14" y="0" width="28" height="34" fill="#3a2a1a" stroke="#0a0d12" strokeWidth="1"/>
          <rect x="-10" y="4" width="20" height="22" fill="#e8caa0" opacity="0.7"/>
        </g>
        <ellipse cx="960" cy="180" rx="200" ry="80" fill="rgba(232,210,170,0.18)"/>
        {/* shelf with trinkets */}
        <g transform="translate(80 480)" fill="#2a2620">
          <rect x="0" y="0" width="240" height="6"/>
          <rect x="20" y="-40" width="20" height="40"/>
          <rect x="60" y="-30" width="14" height="30"/>
          <rect x="100" y="-50" width="18" height="50"/>
          <rect x="140" y="-25" width="22" height="25"/>
        </g>
      </svg>

      <div style={{
        position: "absolute", inset: 0, opacity: 0.18, pointerEvents: "none",
        backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence baseFrequency='0.85' numOctaves='2'/></filter><rect width='300' height='300' filter='url(%23n)'/></svg>\")",
        mixBlendMode: "overlay"
      }}/>

      {/* NPC card — top */}
      <div className="paper" style={{
        position: "absolute", left: "50%", top: 32,
        transform: "translateX(-50%) rotate(-0.5deg)",
        width: 720, padding: "20px 28px 18px",
        boxShadow: "0 16px 32px rgba(0,0,0,0.65)"
      }}>
        <Tape top={-10} left={310} w={100} h={22} rot={2}/>
        <div style={{ display: "flex", gap: 18, alignItems: "flex-start" }}>
          {/* NPC portrait */}
          <div className="tsp-photo" style={{ width: 100, height: 125, border: "1.5px solid var(--tsp-ink)", flex: "0 0 auto" }}>
            <svg viewBox="0 0 100 125" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
              <rect width="100" height="125" fill="#1a1d22"/>
              <circle cx="50" cy="48" r="22" fill="#3a2618"/>
              <path d="M 14 125 Q 50 70 86 125 Z" fill="#3a2618"/>
              {/* beard */}
              <path d="M 30 58 Q 50 78 70 58 Q 65 70 50 73 Q 35 70 30 58 Z" fill="#1a1410"/>
              {/* eye */}
              <path d="M 38 44 L 36 50 M 64 44 L 66 50" stroke="#0a0d12" strokeWidth="1.2"/>
              {/* scar */}
              <line x1="68" y1="34" x2="72" y2="56" stroke="#8a3a2a" strokeWidth="1" opacity="0.8"/>
            </svg>
          </div>

          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <div>
                <div className="t-label" style={{ marginBottom: 2 }}>STAI PARLANDO CON</div>
                <div className="t-serif" style={{ fontSize: 28, lineHeight: 1, fontWeight: 500 }}>Marcus</div>
                <div className="t-hand" style={{ fontSize: 15, color: "var(--tsp-slate)", marginTop: 2 }}>
                  custode dell'Avamposto · ex-poliziotto
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.2em", color: "var(--tsp-slate)" }}>REPUTAZIONE</div>
                <div style={{ display: "flex", gap: 3, marginTop: 4, justifyContent: "flex-end" }}>
                  {[1,2,3,4,5].map(i => (
                    <div key={i} style={{
                      width: 12, height: 12,
                      border: "1.5px solid var(--tsp-ink)",
                      background: i <= 3 ? "var(--tsp-mint)" : "transparent"
                    }}/>
                  ))}
                </div>
                <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-mint)", marginTop: 4 }}>amichevole</div>
              </div>
            </div>
            <hr className="ink-rule-dashed" style={{ margin: "12px 0 8px" }}/>
            <p className="t-serif" style={{ fontSize: 15, fontStyle: "italic", color: "var(--tsp-ink-faded)", lineHeight: 1.45, textWrap: "pretty" }}>
              "Allora, ragazzo. Hai ancora quella faccia da chi cerca qualcosa.
              Cosa posso fare per te?"
            </p>
          </div>
        </div>
      </div>

      {/* exchange — your last lines + his response */}
      <div className="paper" style={{
        position: "absolute", left: "50%", top: 290,
        transform: "translateX(-50%) rotate(0.5deg)",
        width: 720, padding: "20px 28px 20px",
        boxShadow: "0 16px 32px rgba(0,0,0,0.65)"
      }}>
        <div className="t-label-sm" style={{ marginBottom: 12 }}>SCAMBIO RECENTE</div>

        {/* your line */}
        <div style={{ display: "flex", gap: 14, marginBottom: 14 }}>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.2em", color: "var(--tsp-rust)", width: 50, paddingTop: 2 }}>TU</div>
          <div className="t-serif" style={{ flex: 1, fontSize: 16, fontStyle: "italic", lineHeight: 1.45, color: "var(--tsp-ink)" }}>
            "Cerco qualcuno che sappia di una torre radio a nord. Un segnale."
          </div>
        </div>

        {/* his response */}
        <div style={{ display: "flex", gap: 14, marginBottom: 6 }}>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.2em", color: "var(--tsp-ink)", width: 50, paddingTop: 2 }}>LUI</div>
          <div style={{ flex: 1 }}>
            <p className="t-serif" style={{ fontSize: 16, fontStyle: "italic", lineHeight: 1.5, color: "var(--tsp-ink)", textWrap: "pretty" }}>
              "Una torre radio. <em>Ah</em>. Hai aspettato il momento giusto per chiedermelo —
              non sono cose che si dicono a chi passa di qui a caso. C'è una struttura
              vecchia tre giorni a nord-est, oltre Le Spine. Ma chi va, non torna."
            </p>
            <p className="t-serif" style={{ fontSize: 15, fontStyle: "italic", lineHeight: 1.5, color: "var(--tsp-ink-faded)", marginTop: 8, textWrap: "pretty" }}>
              <em>— guarda fuori dalla finestra, poi te. —</em>
            </p>
            <p className="t-serif" style={{ fontSize: 16, fontStyle: "italic", lineHeight: 1.5, color: "var(--tsp-ink)", marginTop: 8, textWrap: "pretty" }}>
              "Tuo padre l'ha cercata, vero? Lo vedo dagli occhi."
            </p>
          </div>
        </div>
      </div>

      {/* choices — bottom card */}
      <div className="paper" style={{
        position: "absolute", left: "50%", bottom: 36,
        transform: "translateX(-50%) rotate(-0.5deg)",
        width: 720, padding: "16px 24px 16px",
        boxShadow: "0 16px 32px rgba(0,0,0,0.65)"
      }}>
        <div className="t-label-sm" style={{ marginBottom: 10 }}>COSA RISPONDI?</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {[
            { k: "1", text: "\"Sì. L'ha cercata. E l'ha trovata, credo.\"", tag: "SINCERITÀ · ELIAN", color: "rust" },
            { k: "2", text: "\"Non parliamo di lui. Dimmi solo come arrivarci.\"", tag: "BRUSCO · −1 REPUT.", color: "slate" },
            { k: "3", text: "\"Cosa sai di lui? Perché lo nomini?\"", tag: "INDAGA · INFO LORE", color: "mint" },
            { k: "4", text: "\"Posso darti qualcosa in cambio delle indicazioni?\"", tag: "BARATTO", color: "ink" },
            { k: "5", text: "\"Lasciamo perdere. Devo andare.\"", tag: "INTERROMPI", color: "ink" },
          ].map((c) => {
            const col = c.color === "rust" ? "var(--tsp-rust)" :
                        c.color === "mint" ? "var(--tsp-mint)" :
                        c.color === "slate" ? "var(--tsp-slate)" :
                        "var(--tsp-ink-faded)";
            return (
              <div key={c.k} style={{
                display: "flex", alignItems: "baseline", gap: 14,
                padding: "8px 12px 7px",
                border: "1px solid rgba(20,24,30,0.3)",
                cursor: "pointer"
              }}>
                <div className="t-sans" style={{
                  fontSize: 11, fontWeight: 600, width: 20, height: 20,
                  lineHeight: "20px", textAlign: "center",
                  border: "1px solid var(--tsp-ink)", color: "var(--tsp-ink)"
                }}>{c.k}</div>
                <div className="t-serif" style={{ flex: 1, fontSize: 14, lineHeight: 1.3 }}>
                  {c.text}
                </div>
                <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.2em", color: col }}>
                  {c.tag}
                </div>
              </div>
            );
          })}
        </div>

        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12 }}>
          <span className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>
            1–5 SCEGLI · T COMMERCIA · R RIPOSA · ESC ESCI
          </span>
          <span className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", opacity: 0.8 }}>
            ogni parola conta
          </span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Dialogue });
