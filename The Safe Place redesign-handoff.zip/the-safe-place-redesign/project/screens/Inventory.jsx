// Inventory.jsx — 2 variants
// A: "Catalogo" — pages of the journal listing items
// B: "Sul Tavolo" — items laid out as objects with hand annotations

// ---------- shared inventory data --------------------------------
const INV_ITEMS = [
  { cat: "armi", name: "Coltello da campo",   weight: 0.6, qty: 1, dur: 78, equipped: true,  rare: "comune",   note: "lama scheggiata" },
  { cat: "armi", name: "Pistola 9mm",         weight: 1.1, qty: 1, dur: 45, equipped: false, rare: "non com.", note: "5 colpi rimasti" },
  { cat: "armi", name: "Arco corto",          weight: 0.8, qty: 1, dur: 62, equipped: false, rare: "comune",   note: "corda da sost." },
  { cat: "armature", name: "Giubbotto consunto", weight: 1.8, qty: 1, dur: 41, equipped: true,  rare: "comune", note: "puzza di fumo" },
  { cat: "armature", name: "Stivali sfondati",   weight: 0.9, qty: 1, dur: 28, equipped: true,  rare: "comune", note: null },
  { cat: "cura",     name: "Bende sporche",      weight: 0.1, qty: 3, dur: null, equipped: false, rare: "comune", note: "non sterili" },
  { cat: "cura",     name: "Antidolorifico",     weight: 0.05,qty: 2, dur: null, equipped: false, rare: "raro",   note: "scadenza '21" },
  { cat: "cura",     name: "Acqua purificata",   weight: 0.4, qty: 1, dur: null, equipped: false, rare: "comune", note: null },
  { cat: "cibo",     name: "Razione militare",   weight: 0.3, qty: 2, dur: null, equipped: false, rare: "non com.", note: null },
  { cat: "cibo",     name: "Bacche secche",      weight: 0.1, qty: 6, dur: null, equipped: false, rare: "comune", note: null },
  { cat: "cibo",     name: "Carne di lupo",      weight: 0.4, qty: 1, dur: null, equipped: false, rare: "non com.", note: "da cuocere" },
  { cat: "mat.",     name: "Metallo recuperato", weight: 0.2, qty: 7, dur: null, equipped: false, rare: "comune", note: null },
  { cat: "mat.",     name: "Stracci puliti",     weight: 0.05,qty: 4, dur: null, equipped: false, rare: "comune", note: null },
  { cat: "mat.",     name: "Legna",              weight: 0.3, qty: 5, dur: null, equipped: false, rare: "comune", note: null },
  { cat: "quest",    name: "Registrazione criptica", weight: 0.1, qty: 1, dur: null, equipped: false, rare: "unico", note: "nastro Anya" },
  { cat: "quest",    name: "Lettera bagnata",    weight: 0.05,qty: 1, dur: null, equipped: false, rare: "unico", note: "del padre" },
];

const CATEGORIES = [
  { k: "armi",     l: "ARMI",      n: 3 },
  { k: "armature", l: "ARMATURE",  n: 2 },
  { k: "cura",     l: "CURA",      n: 3 },
  { k: "cibo",     l: "CIBO",      n: 3 },
  { k: "mat.",     l: "MATERIALI", n: 3 },
  { k: "quest",    l: "QUEST",     n: 2 },
];

// ====================================================================
// VARIANT A — Catalog page (left index, right items)
// ====================================================================
function InventoryA() {
  const [activeCat, setActiveCat] = useState("armi");
  const [selectedIdx, setSelectedIdx] = useState(0);
  const filtered = INV_ITEMS.filter(i => i.cat === activeCat);
  const sel = filtered[selectedIdx] || filtered[0];

  return (
    <div style={{ position: "relative", width: "100%", height: "100%", background: "#0e1115", overflow: "hidden" }}>
      <div style={{
        position: "absolute", inset: 24,
        display: "grid",
        gridTemplateColumns: "220px 1fr 320px",
        gap: 16
      }}>
        {/* LEFT — categories tab (sewn ribbon) */}
        <div className="paper" style={{ padding: "24px 18px", position: "relative" }}>
          <div className="t-label" style={{ marginBottom: 14 }}>INVENTARIO</div>
          <hr className="ink-rule" style={{ marginBottom: 16 }}/>

          <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
            {CATEGORIES.map((c) => {
              const active = c.k === activeCat;
              return (
                <div
                  key={c.k}
                  onClick={() => { setActiveCat(c.k); setSelectedIdx(0); }}
                  style={{
                    display: "flex", justifyContent: "space-between", alignItems: "baseline",
                    padding: "10px 8px 9px",
                    borderBottom: "1px dashed rgba(20,24,30,0.3)",
                    background: active ? "var(--tsp-ink)" : "transparent",
                    color: active ? "var(--tsp-paper)" : "var(--tsp-ink)",
                    cursor: "pointer"
                  }}
                >
                  <span className="t-sans" style={{
                    fontSize: 13, fontWeight: active ? 600 : 500,
                    letterSpacing: active ? "0.24em" : "0.2em"
                  }}>{c.l}</span>
                  <span className="t-sans" style={{
                    fontSize: 11, opacity: 0.7
                  }}>{c.n}</span>
                </div>
              );
            })}
          </div>

          <hr className="ink-rule-dashed" style={{ margin: "20px 0 16px" }}/>

          {/* weight gauge */}
          <div className="t-label-sm" style={{ marginBottom: 8 }}>CARICO</div>
          <div style={{ position: "relative", height: 14, marginBottom: 8 }}>
            <div style={{
              position: "absolute", inset: 0,
              backgroundImage: "repeating-linear-gradient(90deg, rgba(20,24,30,0.2) 0 2px, transparent 2px 8px)",
              border: "1px solid rgba(20,24,30,0.55)"
            }}/>
            <div style={{
              position: "absolute", top: 0, bottom: 0, left: 0, width: "56%",
              backgroundImage: "repeating-linear-gradient(90deg, var(--tsp-ink) 0 2px, transparent 2px 8px)"
            }}/>
            <div style={{
              position: "absolute", top: 0, bottom: 0, left: "80%", width: 2,
              background: "var(--tsp-rust)"
            }}/>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span className="t-serif" style={{ fontSize: 16 }}>8.4<span className="t-sans" style={{ fontSize: 10, color: "var(--tsp-slate)" }}> kg</span></span>
            <span className="t-sans" style={{ fontSize: 11, color: "var(--tsp-slate)", letterSpacing: "0.16em" }}>/ 15 kg</span>
          </div>
          <div className="t-hand" style={{ fontSize: 12, color: "var(--tsp-rust)", marginTop: 4 }}>
            attento: 80% soglia sovraccarico
          </div>

          <hr className="ink-rule-dashed" style={{ margin: "16px 0" }}/>

          <div className="t-label-sm" style={{ marginBottom: 6 }}>EQUIPAGGIATO</div>
          <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-ink)", lineHeight: 1.4 }}>
            · coltello<br/>
            · giubb. consunto<br/>
            · stivali sfondati
          </div>

          {/* bottom stamp */}
          <div style={{ position: "absolute", left: 18, bottom: 18 }}>
            <Stamp rotate={-5} color="rust">CAP. III</Stamp>
          </div>
        </div>

        {/* CENTER — items list */}
        <div className="paper" style={{ padding: "24px 28px", position: "relative", overflow: "hidden" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 12 }}>
            <div>
              <div className="t-label" style={{ marginBottom: 2 }}>CATEGORIA</div>
              <div className="t-serif" style={{ fontSize: 32, lineHeight: 1, letterSpacing: "-0.005em" }}>
                {CATEGORIES.find(c => c.k === activeCat)?.l}
              </div>
            </div>
            <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)" }}>
              ordinati per peso
            </div>
          </div>
          <hr className="ink-rule" style={{ marginBottom: 18 }}/>

          {/* column header */}
          <div style={{ display: "grid", gridTemplateColumns: "1.5fr 60px 60px 80px 60px", gap: 12, paddingBottom: 6, borderBottom: "1px solid var(--tsp-ink)", marginBottom: 4 }}>
            <span className="t-label-sm">OGGETTO</span>
            <span className="t-label-sm" style={{ textAlign: "right" }}>PESO</span>
            <span className="t-label-sm" style={{ textAlign: "right" }}>QTÀ</span>
            <span className="t-label-sm" style={{ textAlign: "right" }}>DURAB.</span>
            <span className="t-label-sm" style={{ textAlign: "right" }}>RARITÀ</span>
          </div>

          {filtered.map((it, i) => {
            const active = i === selectedIdx;
            return (
              <div
                key={it.name}
                onClick={() => setSelectedIdx(i)}
                style={{
                  display: "grid", gridTemplateColumns: "1.5fr 60px 60px 80px 60px",
                  gap: 12, padding: "10px 0 8px",
                  borderBottom: "1px dashed rgba(20,24,30,0.25)",
                  background: active ? "rgba(125,58,42,0.07)" : "transparent",
                  cursor: "pointer"
                }}
              >
                <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                  {active && <span style={{ color: "var(--tsp-rust)", fontSize: 14 }}>›</span>}
                  <span className="t-serif" style={{
                    fontSize: 16,
                    fontWeight: active ? 500 : 400,
                    color: it.equipped ? "var(--tsp-rust)" : "var(--tsp-ink)"
                  }}>
                    {it.name}
                  </span>
                  {it.equipped && (
                    <span className="t-sans" style={{
                      fontSize: 9, letterSpacing: "0.2em",
                      color: "var(--tsp-paper)",
                      background: "var(--tsp-rust)",
                      padding: "1px 5px"
                    }}>EQ</span>
                  )}
                </div>
                <span className="t-sans" style={{ fontSize: 12, textAlign: "right", color: "var(--tsp-slate)" }}>
                  {it.weight} kg
                </span>
                <span className="t-serif" style={{ fontSize: 15, textAlign: "right" }}>
                  ×{it.qty}
                </span>
                <span className="t-sans" style={{ fontSize: 11, textAlign: "right", color: it.dur != null ? (it.dur < 40 ? "var(--tsp-rust)" : "var(--tsp-ink-faded)") : "var(--tsp-slate-light)" }}>
                  {it.dur != null ? `${it.dur}%` : "—"}
                </span>
                <span className="t-hand" style={{
                  fontSize: 13, textAlign: "right",
                  color: it.rare === "unico" ? "var(--tsp-rust)" :
                         it.rare === "raro" ? "var(--tsp-rust-dim)" :
                         "var(--tsp-slate)"
                }}>
                  {it.rare}
                </span>
              </div>
            );
          })}

          {/* footer pagination */}
          <div style={{ position: "absolute", bottom: 18, left: 28, right: 28, display: "flex", justifyContent: "space-between" }}>
            <span className="t-sans" style={{ fontSize: 10, letterSpacing: "0.24em", color: "var(--tsp-slate-light)" }}>
              ← → CATEGORIE · ↑ ↓ SCORRI · ↵ AZIONI
            </span>
            <span className="t-sans" style={{ fontSize: 10, letterSpacing: "0.24em", color: "var(--tsp-slate-light)" }}>
              — pag. 49 —
            </span>
          </div>
        </div>

        {/* RIGHT — detail panel */}
        <div className="paper" style={{ padding: "24px 20px", position: "relative" }}>
          <div className="t-label" style={{ marginBottom: 10 }}>DETTAGLIO</div>

          {/* item "drawing" */}
          <div style={{
            width: "100%", aspectRatio: "4/3",
            border: "1.5px solid var(--tsp-ink)",
            background: "rgba(255,255,255,0.4)",
            display: "flex", alignItems: "center", justifyContent: "center",
            marginBottom: 12,
            position: "relative"
          }}>
            <ItemDrawing item={sel}/>
            {/* corner marks */}
            <span style={{ position: "absolute", top: -1, left: -1, width: 12, height: 12, borderTop: "2px solid var(--tsp-ink)", borderLeft: "2px solid var(--tsp-ink)" }}/>
            <span style={{ position: "absolute", top: -1, right: -1, width: 12, height: 12, borderTop: "2px solid var(--tsp-ink)", borderRight: "2px solid var(--tsp-ink)" }}/>
            <span style={{ position: "absolute", bottom: -1, left: -1, width: 12, height: 12, borderBottom: "2px solid var(--tsp-ink)", borderLeft: "2px solid var(--tsp-ink)" }}/>
            <span style={{ position: "absolute", bottom: -1, right: -1, width: 12, height: 12, borderBottom: "2px solid var(--tsp-ink)", borderRight: "2px solid var(--tsp-ink)" }}/>
          </div>

          <div className="t-serif" style={{ fontSize: 22, lineHeight: 1.1, marginBottom: 2 }}>
            {sel.name}
          </div>
          <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", marginBottom: 12 }}>
            {sel.note || "nessuna nota"}
          </div>

          <hr className="ink-rule-dashed" style={{ marginBottom: 10 }}/>

          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
            <ResourceLine label="PESO" val={`${sel.weight} kg`} />
            <ResourceLine label="QUANTITÀ" val={`×${sel.qty}`} />
            {sel.dur != null && <ResourceLine label="DURABILITÀ" val={`${sel.dur}%`} accent={sel.dur < 40}/>}
            <ResourceLine label="RARITÀ" val={sel.rare} />
            <ResourceLine label="VALORE" val="basso" />
          </div>

          {sel.cat === "armi" && (
            <div style={{ marginTop: 14 }}>
              <div className="t-label-sm" style={{ marginBottom: 6 }}>EFFETTO</div>
              <div className="t-serif" style={{ fontSize: 14, fontStyle: "italic", lineHeight: 1.4 }}>
                "1d6+2 danno taglio · richiede destrezza"
              </div>
            </div>
          )}

          <hr className="ink-rule-dashed" style={{ margin: "14px 0 12px" }}/>

          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {[
              { k: "↵", l: sel.equipped ? "RIMUOVI" : "EQUIPAGGIA" },
              { k: "U", l: "USA / CONSUMA" },
              { k: "D", l: "SCARTA" },
              { k: "S", l: "SMANTELLA" },
            ].map((a) => (
              <div key={a.k} className="tsp-btn" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 12px 6px" }}>
                <span>{a.l}</span>
                <span className="t-sans" style={{ fontSize: 10, opacity: 0.6, letterSpacing: "0.1em" }}>{a.k}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* close hint */}
      <div style={{ position: "absolute", top: 0, right: 0, padding: 24, color: "var(--tsp-paper-edge)" }}>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.32em" }}>ESC CHIUDI</div>
      </div>
    </div>
  );
}

// Simple drawn item icon (placeholder)
function ItemDrawing({ item }) {
  const sw = "var(--tsp-ink)";
  switch (item.cat) {
    case "armi":
      if (item.name.includes("Coltello")) {
        return (
          <svg viewBox="0 0 200 120" style={{ width: "70%", height: "70%" }}>
            <g fill="none" stroke={sw} strokeWidth="1.5" strokeLinecap="round">
              <path d="M 20 60 L 130 50 L 138 60 L 130 70 Z" fill="rgba(20,24,30,0.06)"/>
              <rect x="135" y="55" width="42" height="10" rx="2" fill="rgba(125,58,42,0.18)"/>
              <line x1="142" y1="58" x2="172" y2="58" strokeDasharray="2 2"/>
              <line x1="142" y1="62" x2="172" y2="62" strokeDasharray="2 2"/>
            </g>
          </svg>
        );
      } else if (item.name.includes("Pistola")) {
        return (
          <svg viewBox="0 0 200 120" style={{ width: "70%", height: "70%" }}>
            <g fill="none" stroke={sw} strokeWidth="1.5">
              <path d="M 30 50 L 130 50 L 130 65 L 80 65 L 78 92 L 60 92 L 56 65 L 30 65 Z" fill="rgba(20,24,30,0.08)"/>
              <circle cx="40" cy="58" r="3"/>
              <path d="M 130 50 L 145 50 L 145 60 L 130 60"/>
            </g>
          </svg>
        );
      }
      return (
        <svg viewBox="0 0 200 120" style={{ width: "70%", height: "70%" }}>
          <g fill="none" stroke={sw} strokeWidth="1.5">
            <path d="M 50 20 Q 30 60 50 100" fill="rgba(20,24,30,0.05)"/>
            <line x1="50" y1="20" x2="50" y2="100" strokeDasharray="3 3"/>
            <path d="M 50 60 L 160 60" strokeWidth="2"/>
            <path d="M 155 56 L 165 60 L 155 64"/>
          </g>
        </svg>
      );
    case "armature":
      return (
        <svg viewBox="0 0 200 120" style={{ width: "70%", height: "70%" }}>
          <g fill="none" stroke={sw} strokeWidth="1.5">
            <path d="M 60 30 L 80 20 L 120 20 L 140 30 L 150 50 L 140 100 L 60 100 L 50 50 Z" fill="rgba(20,24,30,0.06)"/>
            <path d="M 90 22 Q 100 28 110 22"/>
            <line x1="100" y1="35" x2="100" y2="100"/>
            <line x1="60" y1="55" x2="140" y2="55" strokeDasharray="2 2"/>
          </g>
        </svg>
      );
    case "cura":
      return (
        <svg viewBox="0 0 200 120" style={{ width: "60%", height: "60%" }}>
          <g fill="none" stroke={sw} strokeWidth="1.5">
            <rect x="50" y="30" width="100" height="65" rx="6" fill="rgba(125,58,42,0.10)"/>
            <line x1="100" y1="42" x2="100" y2="83"/>
            <line x1="79" y1="62" x2="121" y2="62"/>
          </g>
        </svg>
      );
    case "cibo":
      return (
        <svg viewBox="0 0 200 120" style={{ width: "60%", height: "60%" }}>
          <g fill="none" stroke={sw} strokeWidth="1.5">
            <path d="M 60 35 L 140 35 L 145 95 L 55 95 Z" fill="rgba(20,24,30,0.06)"/>
            <rect x="65" y="45" width="70" height="22" fill="rgba(20,24,30,0.10)"/>
            <text x="100" y="60" textAnchor="middle" fontFamily="var(--tsp-sans)" fontSize="9" letterSpacing="2" fill="var(--tsp-ink)">RAZIONE</text>
          </g>
        </svg>
      );
    case "mat.":
      return (
        <svg viewBox="0 0 200 120" style={{ width: "55%", height: "55%" }}>
          <g fill="none" stroke={sw} strokeWidth="1.5">
            <path d="M 50 80 L 80 30 L 120 50 L 150 90 L 100 110 Z" fill="rgba(20,24,30,0.08)"/>
            <line x1="80" y1="30" x2="120" y2="50" strokeDasharray="2 2"/>
          </g>
        </svg>
      );
    case "quest":
      return (
        <svg viewBox="0 0 200 120" style={{ width: "60%", height: "60%" }}>
          <g fill="none" stroke={sw} strokeWidth="1.5">
            <path d="M 50 20 L 150 20 L 150 100 L 50 100 Z" fill="rgba(216,210,194,0.5)"/>
            <line x1="60" y1="40" x2="140" y2="40"/>
            <line x1="60" y1="52" x2="140" y2="52"/>
            <line x1="60" y1="64" x2="120" y2="64"/>
            <line x1="60" y1="76" x2="135" y2="76"/>
            <line x1="60" y1="88" x2="110" y2="88"/>
          </g>
        </svg>
      );
    default:
      return null;
  }
}

// ====================================================================
// VARIANT B — "Sul Tavolo" — items strewn on a desk
// ====================================================================
function InventoryB() {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden",
      background: `
        radial-gradient(ellipse 80% 60% at 50% 50%, #2a2620, #14110d 100%)
      `
    }}>
      <div style={{
        position: "absolute", inset: 0, opacity: 0.18, pointerEvents: "none",
        backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='400' height='400'><filter id='n'><feTurbulence baseFrequency='1.2' numOctaves='2' seed='9'/></filter><rect width='400' height='400' filter='url(%23n)'/></svg>\")",
        mixBlendMode: "overlay"
      }}/>

      {/* header strip */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0,
        padding: "20px 32px",
        display: "flex", justifyContent: "space-between", alignItems: "center",
        color: "var(--tsp-paper)"
      }}>
        <div>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.4em", opacity: 0.55, marginBottom: 4 }}>
            CIÒ CHE HAI ADDOSSO
          </div>
          <div className="t-serif" style={{ fontSize: 28, lineHeight: 1 }}>
            Zaino
          </div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.32em", opacity: 0.55 }}>CARICO</div>
          <div className="t-serif" style={{ fontSize: 24 }}>
            8.4<span className="t-sans" style={{ fontSize: 14, color: "var(--tsp-slate-light)" }}> / 15 kg</span>
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.32em", opacity: 0.55 }}>OGGETTI</div>
          <div className="t-serif" style={{ fontSize: 24 }}>16</div>
        </div>
      </div>

      {/* large notebook background — list view */}
      <div className="paper" style={{
        position: "absolute", left: 32, top: 90, bottom: 64, width: 380,
        padding: "18px 20px",
        transform: "rotate(-1deg)",
        boxShadow: "0 16px 32px rgba(0,0,0,0.6)"
      }}>
        <div className="t-label" style={{ marginBottom: 10 }}>SCHEDA OGGETTI</div>
        <hr className="ink-rule" style={{ marginBottom: 14 }}/>
        <div style={{ display: "flex", flexDirection: "column", gap: 0, maxHeight: "calc(100% - 90px)", overflow: "hidden" }}>
          {INV_ITEMS.slice(0, 12).map((it, i) => (
            <div key={it.name} style={{
              display: "flex", justifyContent: "space-between", alignItems: "baseline",
              padding: "7px 0",
              borderBottom: "1px dashed rgba(20,24,30,0.2)"
            }}>
              <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
                <span className="t-sans" style={{ fontSize: 9, color: "var(--tsp-slate-light)", letterSpacing: "0.16em", width: 32 }}>
                  {it.cat.toUpperCase()}
                </span>
                <span className="t-serif" style={{ fontSize: 14, color: it.equipped ? "var(--tsp-rust)" : "var(--tsp-ink)" }}>
                  {it.name}
                </span>
              </div>
              <div style={{ display: "flex", gap: 10, alignItems: "baseline" }}>
                <span className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)" }}>×{it.qty}</span>
                <span className="t-sans" style={{ fontSize: 10, color: "var(--tsp-slate-light)", width: 36, textAlign: "right" }}>{it.weight}kg</span>
              </div>
            </div>
          ))}
        </div>
        <div style={{ position: "absolute", bottom: 14, left: 20, right: 20, display: "flex", justifyContent: "space-between" }}>
          <span className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)" }}>… +4 oggetti</span>
          <span className="t-sans" style={{ fontSize: 9, letterSpacing: "0.24em", color: "var(--tsp-slate-light)" }}>pag. 49</span>
        </div>
      </div>

      {/* item objects laid on table */}
      {/* knife — large, central */}
      <div style={{ position: "absolute", left: 470, top: 130, transform: "rotate(-18deg)" }}>
        <svg width="260" height="80" viewBox="0 0 260 80" style={{ filter: "drop-shadow(0 8px 14px rgba(0,0,0,0.7))" }}>
          <g>
            <path d="M 10 40 L 165 30 L 175 40 L 165 50 Z" fill="#a8acb0" stroke="#1a1d22" strokeWidth="1.2"/>
            <path d="M 10 40 L 165 30 L 175 40 L 165 50 Z" fill="url(#bladeGrad)" opacity="0.6"/>
            <defs>
              <linearGradient id="bladeGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#e0e4e8"/>
                <stop offset="100%" stopColor="#6e7278"/>
              </linearGradient>
            </defs>
            <rect x="170" y="34" width="60" height="14" rx="2" fill="#5a3e28" stroke="#1a1d22" strokeWidth="1.2"/>
            <line x1="180" y1="38" x2="225" y2="38" stroke="#2a1d10" strokeWidth="1"/>
            <line x1="180" y1="42" x2="225" y2="42" stroke="#2a1d10" strokeWidth="1"/>
            <line x1="180" y1="46" x2="225" y2="46" stroke="#2a1d10" strokeWidth="1"/>
            {/* nick */}
            <path d="M 60 32 L 70 36" stroke="#1a1d22" strokeWidth="0.6" opacity="0.5"/>
          </g>
        </svg>
        <div style={{ position: "absolute", right: -160, top: 30, width: 160 }}>
          <div className="t-hand" style={{ fontSize: 16, color: "var(--tsp-paper)", lineHeight: 1.2, opacity: 0.92 }}>
            "lama scheggiata,<br/>ma taglia ancora"
          </div>
          <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.3em", color: "var(--tsp-rust)", marginTop: 4 }}>EQUIPAGGIATO</div>
        </div>
      </div>

      {/* bullets */}
      <div style={{ position: "absolute", left: 530, top: 280, transform: "rotate(8deg)" }}>
        <svg width="220" height="40" viewBox="0 0 220 40" style={{ filter: "drop-shadow(0 6px 10px rgba(0,0,0,0.6))" }}>
          {[10, 50, 90, 130, 170].map((x, i) => (
            <g key={i} transform={`translate(${x} 12) rotate(${(i % 2 === 0 ? -3 : 4)})`}>
              <rect x="0" y="0" width="22" height="14" rx="2" fill="#b08858"/>
              <path d="M 22 0 L 32 7 L 22 14 Z" fill="#7a5430"/>
            </g>
          ))}
        </svg>
        <div className="t-hand" style={{ position: "absolute", left: 0, top: -22, fontSize: 14, color: "var(--tsp-paper)", opacity: 0.9 }}>
          5 colpi · 9mm
        </div>
      </div>

      {/* bandages */}
      <div style={{ position: "absolute", left: 760, top: 130, transform: "rotate(12deg)" }}>
        <svg width="120" height="120" viewBox="0 0 120 120" style={{ filter: "drop-shadow(0 8px 14px rgba(0,0,0,0.6))" }}>
          <ellipse cx="60" cy="60" rx="42" ry="40" fill="#d4cbb0" stroke="#1a1d22" strokeWidth="1.2"/>
          <ellipse cx="60" cy="60" rx="42" ry="40" fill="url(#cloth)" opacity="0.4"/>
          <defs>
            <pattern id="cloth" x="0" y="0" width="4" height="4" patternUnits="userSpaceOnUse">
              <path d="M 0 0 L 4 4 M 4 0 L 0 4" stroke="#8a8270" strokeWidth="0.4"/>
            </pattern>
          </defs>
          <path d="M 22 50 Q 60 30 98 56" fill="none" stroke="#8a3a2a" strokeWidth="2.5" opacity="0.65"/>
          <text x="60" y="100" textAnchor="middle" fontFamily="var(--tsp-sans)" fontSize="8" letterSpacing="2" fill="#1a1d22">BENDE × 3</text>
        </svg>
      </div>

      {/* food can */}
      <div style={{ position: "absolute", left: 870, top: 260, transform: "rotate(-7deg)" }}>
        <svg width="100" height="130" viewBox="0 0 100 130" style={{ filter: "drop-shadow(0 8px 14px rgba(0,0,0,0.6))" }}>
          <rect x="22" y="20" width="56" height="90" rx="3" fill="#8a8378" stroke="#1a1d22" strokeWidth="1.2"/>
          <rect x="22" y="20" width="56" height="90" rx="3" fill="url(#tinShine)" opacity="0.4"/>
          <defs>
            <linearGradient id="tinShine" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#e8eaed"/>
              <stop offset="50%" stopColor="transparent"/>
              <stop offset="100%" stopColor="#1a1d22"/>
            </linearGradient>
          </defs>
          <rect x="20" y="38" width="60" height="22" fill="#d4cbb0" stroke="#1a1d22" strokeWidth="0.8"/>
          <text x="50" y="50" textAnchor="middle" fontFamily="var(--tsp-sans)" fontSize="7" letterSpacing="1" fill="#1a1d22">RAZIONE</text>
          <text x="50" y="56" textAnchor="middle" fontFamily="var(--tsp-sans)" fontSize="5" letterSpacing="1" fill="#1a1d22">MILITARE T-9</text>
          {/* rust */}
          <path d="M 26 90 Q 30 95 28 105" stroke="#5a2d20" strokeWidth="1.5" fill="none" opacity="0.5"/>
        </svg>
        <div className="t-hand" style={{ position: "absolute", left: -50, top: 95, fontSize: 14, color: "var(--tsp-paper)", opacity: 0.9 }}>× 2</div>
      </div>

      {/* letter — quest item */}
      <div style={{ position: "absolute", left: 470, top: 380, transform: "rotate(4deg)" }}>
        <div className="paper" style={{
          width: 220, height: 110,
          padding: "10px 14px",
          boxShadow: "0 10px 18px rgba(0,0,0,0.55)"
        }}>
          <div className="t-hand" style={{ fontSize: 16, color: "var(--tsp-ink)", lineHeight: 1.2, opacity: 0.9 }}>
            "Ultimo,<br/>se leggi questo<br/>vai a nord, dove..."
          </div>
          <div className="t-sans" style={{ fontSize: 8, letterSpacing: "0.3em", color: "var(--tsp-slate)", position: "absolute", bottom: 8, right: 12 }}>
            BAGNATA · CAP. I
          </div>
          <Stamp rotate={-12} color="rust" style={{ position: "absolute", top: -8, right: -10, fontSize: 9, padding: "2px 6px", borderWidth: 2 }}>QUEST</Stamp>
        </div>
      </div>

      {/* materials — scrap */}
      <div style={{ position: "absolute", left: 770, top: 410, transform: "rotate(10deg)" }}>
        <svg width="120" height="90" viewBox="0 0 120 90" style={{ filter: "drop-shadow(0 6px 12px rgba(0,0,0,0.6))" }}>
          <polygon points="20,60 50,20 90,30 105,70 60,80" fill="#6e7278" stroke="#1a1d22" strokeWidth="1.2"/>
          <polygon points="20,60 50,20 90,30 105,70 60,80" fill="url(#metalShine)" opacity="0.45"/>
          <defs>
            <linearGradient id="metalShine" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#d8dbe0"/>
              <stop offset="100%" stopColor="#1a1d22"/>
            </linearGradient>
          </defs>
          <line x1="50" y1="20" x2="60" y2="80" stroke="#1a1d22" strokeWidth="0.6" opacity="0.5"/>
        </svg>
        <div className="t-hand" style={{ position: "absolute", left: 0, bottom: -16, fontSize: 14, color: "var(--tsp-paper)", opacity: 0.9 }}>
          metallo × 7
        </div>
      </div>

      {/* selection / focus card top-right */}
      <div className="paper" style={{
        position: "absolute", right: 32, top: 90, width: 280,
        padding: "16px 18px",
        transform: "rotate(1.5deg)",
        boxShadow: "0 14px 26px rgba(0,0,0,0.6)"
      }}>
        <div className="t-label-sm" style={{ marginBottom: 4, color: "var(--tsp-rust)" }}>SELEZIONATO</div>
        <div className="t-serif" style={{ fontSize: 22, lineHeight: 1 }}>Coltello da campo</div>
        <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", marginTop: 2 }}>
          lama scheggiata
        </div>
        <hr className="ink-rule-dashed" style={{ margin: "12px 0 10px" }}/>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <ResourceLine label="DANNO" val="1d6 + 2" />
          <ResourceLine label="PESO" val="0.6 kg" />
          <ResourceLine label="DURABILITÀ" val="78%" />
        </div>
        <hr className="ink-rule-dashed" style={{ margin: "12px 0 10px" }}/>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <div className="tsp-btn" style={{ flex: 1, fontSize: 10, padding: "6px 8px 5px", textAlign: "center" }}>RIMUOVI</div>
          <div className="tsp-btn" style={{ flex: 1, fontSize: 10, padding: "6px 8px 5px", textAlign: "center" }}>RIPARA</div>
        </div>
        <div className="tsp-btn tsp-btn-rust" style={{ marginTop: 6, fontSize: 10, padding: "6px 8px 5px", textAlign: "center" }}>SMANTELLA</div>
        <Tape top={-10} right={70} w={70} h={18} rot={-5}/>
      </div>

      {/* bottom hint */}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "16px 32px", display: "flex", justifyContent: "space-between" }}>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.32em", color: "rgba(216,210,194,0.6)" }}>
          ↑ ↓ NAVIGA · ↵ AZIONI · TAB CAMBIA VISTA · ESC CHIUDI
        </div>
        <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-mint)", opacity: 0.85 }}>
          "tre giorni di provviste, forse quattro"
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { InventoryA, InventoryB });
