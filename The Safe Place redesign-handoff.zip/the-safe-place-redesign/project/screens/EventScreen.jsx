// EventScreen.jsx — narrative event / cutscene, 2 variants
// A: Atmospheric immersive — photo-like backdrop + journal-style narration
// B: Letter/paper-only — narrative as a found document, no images

// ====================================================================
// VARIANT A — Atmospheric, photo backdrop + journal narration
// ====================================================================
function EventScreenA() {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden", background: "#0a0d12" }}>
      {/* photo backdrop — desaturated scene */}
      <svg viewBox="0 0 1280 720" preserveAspectRatio="xMidYMid slice"
           style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        <defs>
          <linearGradient id="evSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2a3340"/>
            <stop offset="50%" stopColor="#3a4654"/>
            <stop offset="100%" stopColor="#5a6470"/>
          </linearGradient>
          <radialGradient id="evVig" cx="50%" cy="50%" r="80%">
            <stop offset="50%" stopColor="rgba(0,0,0,0)"/>
            <stop offset="100%" stopColor="rgba(0,0,0,0.85)"/>
          </radialGradient>
        </defs>
        <rect width="1280" height="720" fill="url(#evSky)"/>
        {/* forest silhouette */}
        <g fill="#161a22" opacity="0.95">
          <rect x="0" y="500" width="1280" height="220"/>
          {/* trees */}
          {Array.from({ length: 20 }).map((_, i) => {
            const x = i * 70 + (i % 3) * 8;
            const h = 80 + (i * 13) % 60;
            return (
              <g key={i}>
                <rect x={x - 3} y={500 - h + 30} width="6" height={h - 30} fill="#0e1115"/>
                <polygon points={`${x-22},${500-h+40} ${x},${500-h} ${x+22},${500-h+40}`} fill="#0e1115"/>
                <polygon points={`${x-18},${500-h+60} ${x},${500-h+25} ${x+18},${500-h+60}`} fill="#0e1115"/>
                <polygon points={`${x-15},${500-h+80} ${x},${500-h+45} ${x+15},${500-h+80}`} fill="#0e1115"/>
              </g>
            );
          })}
        </g>
        {/* light through trees */}
        <g opacity="0.18">
          {[200, 480, 760, 1020].map((x, i) => (
            <polygon key={i} points={`${x},0 ${x+30},0 ${x+200},500 ${x+170},500`} fill="#e8eaed"/>
          ))}
        </g>
        {/* lone figure in middle distance */}
        <g transform="translate(680 480)" fill="#0a0d12">
          <ellipse cx="0" cy="-15" rx="6" ry="8"/>
          <path d="M -5 -8 L 5 -8 L 4 30 L -4 30 Z"/>
          <path d="M -7 -2 L -16 16 L -12 26 L -5 12 Z"/>
          <path d="M 4 0 L 14 12 L 22 6 L 8 -8 Z"/>
        </g>
        {/* fog layer */}
        <rect y="400" width="1280" height="320" fill="url(#evVig)"/>
        <rect width="1280" height="720" fill="url(#evVig)"/>
      </svg>

      {/* grain over photo */}
      <div style={{
        position: "absolute", inset: 0, opacity: 0.25, pointerEvents: "none",
        backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence baseFrequency='0.8' numOctaves='2'/></filter><rect width='300' height='300' filter='url(%23n)'/></svg>\")",
        mixBlendMode: "overlay"
      }}/>

      {/* event header — small label top */}
      <div style={{
        position: "absolute", top: 32, left: 0, right: 0,
        textAlign: "center", color: "var(--tsp-paper-edge)"
      }}>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.5em", marginBottom: 6, opacity: 0.55 }}>
          EVENTO · FORESTA DEI SOSPIRI
        </div>
        <div className="t-hand" style={{ fontSize: 18, color: "var(--tsp-ice-glow)", opacity: 0.85 }}>
          la luce del mattino non basta
        </div>
      </div>

      {/* paper letter at lower-half — narration */}
      <div className="paper" style={{
        position: "absolute",
        left: "50%", bottom: 56,
        transform: "translateX(-50%) rotate(-0.8deg)",
        width: 720, padding: "32px 40px 28px",
        boxShadow: "0 30px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,0,0,0.3)"
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 10 }}>
          <div className="t-label" style={{ fontSize: 10 }}>LA SAGOMA</div>
          <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate)" }}>
            CAP. III · VOCE 47 · 06:42
          </div>
        </div>
        <hr className="ink-rule" style={{ marginBottom: 16 }}/>

        <p className="t-serif" style={{ fontSize: 18, lineHeight: 1.55, textWrap: "pretty", marginBottom: 12, color: "var(--tsp-ink)" }}>
          Ti fermi a metà del passo. Tra i tronchi neri della Foresta dei Sospiri
          qualcosa <em style={{ color: "var(--tsp-rust)" }}>si muove</em>. Non un animale —
          troppo grande, troppo silenzioso. Una sagoma scura, alta quanto te, ferma.
        </p>
        <p className="t-serif" style={{ fontSize: 16, lineHeight: 1.55, textWrap: "pretty", marginBottom: 14, color: "var(--tsp-ink-faded)", fontStyle: "italic" }}>
          Hai sentito storie di chi cammina nella nebbia. Storie di chi non torna.
          La nebbia oggi è fitta, ma la pistola è in tasca, e la gamba ferita brucia.
        </p>

        <hr className="ink-rule-dashed" style={{ marginBottom: 14 }}/>

        {/* choices */}
        <div className="t-label-sm" style={{ marginBottom: 10 }}>COSA FAI?</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {[
            { k: "1", text: "Rimani immobile. Lascia che passi.", tag: "FURTIVITÀ DC 13", color: "ink" },
            { k: "2", text: "Chiama. Forse è una persona, forse aiuta.", tag: "CARISMA · RISCHIOSO", color: "mint" },
            { k: "3", text: "Spara prima che si avvicini.", tag: "PISTOLA · 1 COLPO", color: "rust" },
            { k: "4", text: "Allontanati lentamente verso est.", tag: "ACROBAZIA DC 11", color: "slate" },
          ].map((c) => (
            <div key={c.k} style={{
              display: "flex", alignItems: "baseline", gap: 14,
              padding: "9px 12px 7px",
              border: "1px solid rgba(20,24,30,0.3)",
              background: "rgba(20,24,30,0.02)",
              cursor: "pointer"
            }}>
              <div className="t-sans" style={{
                fontSize: 12, fontWeight: 600,
                width: 22, height: 22, lineHeight: "22px", textAlign: "center",
                border: "1px solid var(--tsp-ink)",
                color: "var(--tsp-ink)", flex: "0 0 auto"
              }}>{c.k}</div>
              <div className="t-serif" style={{ flex: 1, fontSize: 15, lineHeight: 1.3 }}>
                {c.text}
              </div>
              <div className="t-sans" style={{
                fontSize: 9, letterSpacing: "0.22em",
                color: c.color === "rust" ? "var(--tsp-rust)" :
                       c.color === "mint" ? "var(--tsp-mint)" :
                       c.color === "slate" ? "var(--tsp-slate)" :
                       "var(--tsp-ink-faded)"
              }}>
                {c.tag}
              </div>
            </div>
          ))}
        </div>

        <div style={{ marginTop: 16, display: "flex", justifyContent: "space-between" }}>
          <span className="t-sans" style={{ fontSize: 9, letterSpacing: "0.3em", color: "var(--tsp-slate-light)" }}>
            1–4 SCEGLI · INVIO CONFERMA
          </span>
          <span className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)", opacity: 0.8 }}>
            ogni scelta lascia un segno
          </span>
        </div>

        <Tape top={-10} left={310} w={100} h={22} rot={-2}/>
      </div>
    </div>
  );
}

// ====================================================================
// VARIANT B — Letter / cutscene — paper only, full focus on text
// ====================================================================
function EventScreenB() {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden",
      background: "radial-gradient(ellipse 60% 50% at 50% 50%, #1a1d22, #0a0d12 100%)"
    }}>
      {/* dust particles */}
      {Array.from({ length: 22 }).map((_, i) => (
        <div key={i} style={{
          position: "absolute",
          width: 1 + (i % 2),
          height: 1 + (i % 2),
          left: `${(i * 41) % 100}%`,
          top: `${(i * 29) % 100}%`,
          background: "rgba(220,228,235,0.3)",
          borderRadius: "50%"
        }}/>
      ))}

      {/* the letter — large, centered */}
      <div className="paper" style={{
        position: "absolute",
        left: "50%", top: "50%",
        transform: "translate(-50%, -50%) rotate(-1deg)",
        width: 680, minHeight: 600,
        padding: "48px 56px",
        boxShadow: "0 40px 80px rgba(0,0,0,0.8), 0 0 0 1px rgba(0,0,0,0.4)"
      }}>
        {/* burn mark / coffee */}
        <div style={{
          position: "absolute", top: -8, right: 60,
          width: 80, height: 24,
          background: "radial-gradient(ellipse, rgba(74,52,32,0.35), transparent 70%)",
          filter: "blur(3px)", pointerEvents: "none"
        }}/>

        {/* stamp */}
        <div style={{ position: "absolute", top: 18, right: 38 }}>
          <Stamp rotate={-12} color="rust">EVENTO RARO</Stamp>
        </div>

        <div className="t-label" style={{ fontSize: 10, marginBottom: 4 }}>UN RICORDO · ECHO IV</div>
        <div className="t-serif" style={{ fontSize: 44, lineHeight: 0.95, fontWeight: 500, letterSpacing: "-0.01em", marginBottom: 16 }}>
          La mano<br/>di mio padre
        </div>
        <hr className="ink-rule" style={{ marginBottom: 26 }}/>

        <p className="t-serif" style={{ fontSize: 17, lineHeight: 1.65, textWrap: "pretty", color: "var(--tsp-ink)", marginBottom: 14 }}>
          Il bosco è lo stesso. Ti rendi conto solo ora, dopo undici anni —
          è lo stesso esatto sentiero. Lo stesso muschio sulle radici, lo stesso
          modo in cui la luce cade tra le betulle.
        </p>

        <p className="t-serif" style={{ fontSize: 17, lineHeight: 1.65, textWrap: "pretty", color: "var(--tsp-ink-faded)", fontStyle: "italic", marginBottom: 14 }}>
          Tuo padre ti teneva la mano destra. Ricordi che la sua mano era
          calda anche d'inverno. Ricordi la sua voce — "<span style={{ color: "var(--tsp-rust)" }}>non guardare indietro,
          Ultimo. Guarda solo dove metti il piede.</span>"
        </p>

        <p className="t-serif" style={{ fontSize: 17, lineHeight: 1.65, textWrap: "pretty", color: "var(--tsp-ink)", marginBottom: 22 }}>
          Hai fatto come ti aveva detto. Per anni. Forse troppo a lungo.
        </p>

        <hr className="ink-rule-dashed" style={{ marginBottom: 22 }}/>

        <div className="t-label-sm" style={{ marginBottom: 12, color: "var(--tsp-rust)" }}>
          DOPO TUTTI QUESTI ANNI, COSA TI DICI?
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{
            padding: "12px 16px 10px",
            background: "transparent",
            borderLeft: "2px solid var(--tsp-rust)",
            cursor: "pointer"
          }}>
            <div className="t-serif" style={{ fontSize: 17, lineHeight: 1.4, fontStyle: "italic" }}>
              "Avevi ragione. Non guardo indietro."
            </div>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate)", marginTop: 6 }}>
              ALLINEAMENTO · ELIAN +2 · PRAGMATISMO
            </div>
          </div>
          <div style={{
            padding: "12px 16px 10px",
            borderLeft: "2px solid var(--tsp-mint)",
            cursor: "pointer"
          }}>
            <div className="t-serif" style={{ fontSize: 17, lineHeight: 1.4, fontStyle: "italic" }}>
              "Mi manchi. Tutti i giorni."
            </div>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate)", marginTop: 6 }}>
              ALLINEAMENTO · LENA +2 · COMPASSIONE
            </div>
          </div>
          <div style={{
            padding: "12px 16px 10px",
            borderLeft: "2px solid var(--tsp-slate)",
            cursor: "pointer"
          }}>
            <div className="t-serif" style={{ fontSize: 17, lineHeight: 1.4, fontStyle: "italic" }}>
              "Forse non avresti dovuto."
            </div>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate)", marginTop: 6 }}>
              MEMORIA · SBLOCCA "IL DUBBIO"
            </div>
          </div>
        </div>

        <div style={{ marginTop: 26, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span className="t-hand" style={{ fontSize: 15, color: "var(--tsp-slate)" }}>
            — la mano scivola via —
          </span>
          <span className="t-sans" style={{ fontSize: 10, letterSpacing: "0.3em", color: "var(--tsp-slate)" }}>
            ↑ ↓ SCEGLI · ↵ DI'
          </span>
        </div>

        {/* corner pin */}
        <Pin top={-8} left={50} variant="rust"/>
        <Pin bottom={-8} right={50} variant="bone"/>
      </div>

      {/* tiny footer */}
      <div style={{ position: "absolute", bottom: 18, left: 0, right: 0, textAlign: "center" }}>
        <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.4em", color: "rgba(216,210,194,0.4)" }}>
          ECHO DELLA MEMORIA · IV / XII · SOLO ALL'ALBA
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { EventScreenA, EventScreenB });
