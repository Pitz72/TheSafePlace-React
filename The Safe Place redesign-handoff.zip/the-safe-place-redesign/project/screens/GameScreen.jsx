// GameScreen.jsx — main exploration screen, 3 layout variants
// A: Mappa full-bleed + overlay flottanti (immersivo)
// B: Doppia pagina di diario (libro aperto)
// C: Tavolo di lavoro / corkboard (cartografo)

// ====================================================================
// VARIANT A — Full-bleed map with floating overlays
// ====================================================================
function GameScreenA({ mood = "day" }) {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", background: "#0e1115", overflow: "hidden" }}>
      {/* full-bleed paper map */}
      <div style={{ position: "absolute", inset: 0, padding: 0 }}>
        <PaperMap width="100%" height="100%" mood={mood} showCompass={false} />
      </div>

      {/* top bar — survivor identity + time */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0,
        padding: "18px 32px",
        background: "linear-gradient(180deg, rgba(20,24,32,0.85), rgba(20,24,32,0.0))",
        color: "var(--tsp-paper)",
        display: "flex", justifyContent: "space-between", alignItems: "flex-start"
      }}>
        <div>
          <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.4em", opacity: 0.55, marginBottom: 4 }}>SOPRAVVISSUTO</div>
          <div className="t-serif" style={{ fontSize: 22, lineHeight: 1, letterSpacing: "0.01em" }}>Ultimo</div>
          <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-mint)", marginTop: 2, opacity: 0.85 }}>
            figlio del custode
          </div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.4em", opacity: 0.55, marginBottom: 4 }}>
            GIORNO 14 · CAP. III
          </div>
          <div className="t-serif" style={{ fontSize: 22, letterSpacing: "0.04em" }}>Le Spine</div>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.3em", color: "var(--tsp-ice-glow)", marginTop: 2 }}>
            06:42 · ALBA
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.4em", opacity: 0.55, marginBottom: 4 }}>METEO</div>
          <div className="t-hand" style={{ fontSize: 18, color: "var(--tsp-ice-glow)" }}>nebbia fitta</div>
          <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.2em", opacity: 0.65, marginTop: 4 }}>
            visibilità ridotta · −2 percezione
          </div>
        </div>
      </div>

      {/* left HUD — stats panel, paper card pinned */}
      <div style={{
        position: "absolute", left: 24, top: 110, width: 240,
        background: "var(--tsp-paper)",
        padding: "18px 18px 14px",
        boxShadow: "0 10px 30px rgba(0,0,0,0.5), 0 0 0 1px rgba(0,0,0,0.3)",
        transform: "rotate(-1.5deg)"
      }}>
        <Tape top={-10} left={80} w={80} h={20} rot={3}/>
        <div className="t-label" style={{ marginBottom: 12 }}>STATO</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
          <StatMeter label="VITA"     value={68} max={100} color="rust"/>
          <StatMeter label="SAZIETÀ"  value={42} max={100} color="ink"/>
          <StatMeter label="ACQUA"    value={31} max={100} color="slate"/>
          <StatMeter label="FATICA"   value={78} max={100} color="ink"/>
        </div>
        <hr className="ink-rule-dashed" style={{ margin: "12px 0" }}/>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span className="t-label-sm">CONDIZIONI</span>
          </div>
          <div className="t-hand" style={{ fontSize: 15, color: "var(--tsp-rust)" }}>· ferito (gamba)</div>
          <div className="t-hand" style={{ fontSize: 15, color: "var(--tsp-slate)" }}>· affamato</div>
        </div>
        <hr className="ink-rule-dashed" style={{ margin: "12px 0" }}/>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <span className="t-label-sm">LIVELLO</span>
          <span className="t-serif" style={{ fontSize: 18 }}>4 <span className="t-sans" style={{ fontSize: 10, color: "var(--tsp-slate-light)" }}>· 320/500 XP</span></span>
        </div>
      </div>

      {/* right HUD — journal entries flowing */}
      <div style={{
        position: "absolute", right: 24, top: 110, width: 320,
        background: "var(--tsp-paper)",
        padding: "18px 20px 14px",
        boxShadow: "0 10px 30px rgba(0,0,0,0.5), 0 0 0 1px rgba(0,0,0,0.3)",
        transform: "rotate(1deg)",
        maxHeight: 480, overflow: "hidden"
      }}>
        <Tape top={-10} right={70} w={80} h={20} rot={-4}/>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 12 }}>
          <div className="t-label">DIARIO DI VIAGGIO</div>
          <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.18em", color: "var(--tsp-slate-light)" }}>14 VOCI · OGGI</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          <JournalEntry time="06:42">L'alba ti coglie sul ciglio della collina. La nebbia divora i campi.</JournalEntry>
          <JournalEntry time="06:38" tone="muted">Hai dormito tre ore. Niente è bastato.</JournalEntry>
          <JournalEntry time="06:15" tone="rust">Una sagoma si è mossa nei rovi. Sei rimasto fermo.</JournalEntry>
          <JournalEntry time="05:50">Hai bevuto le ultime gocce dalla borraccia.</JournalEntry>
          <JournalEntry time="05:30" hand={true} tone="mint">— Domani trovo l'acqua. Domani sempre.</JournalEntry>
          <JournalEntry time="04:12" tone="muted">Hai sentito un canto in lontananza. Probabilmente il vento.</JournalEntry>
          <JournalEntry time="03:48">Hai applicato una benda sulla gamba destra.</JournalEntry>
        </div>
      </div>

      {/* bottom action bar — keyboard hints + minor info */}
      <div style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        padding: "16px 32px",
        background: "linear-gradient(0deg, rgba(20,24,32,0.85), rgba(20,24,32,0.0))",
        color: "var(--tsp-paper)",
        display: "flex", justifyContent: "space-between", alignItems: "center"
      }}>
        <div style={{ display: "flex", gap: 28 }}>
          {[
            ["WASD", "muoviti"],
            ["I", "inventario"],
            ["J", "quest"],
            ["F", "cerca"],
            ["R", "riposa"],
            ["E", "interagisci"],
          ].map(([k, l]) => (
            <div key={k} style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div className="t-sans" style={{
                fontSize: 11, fontWeight: 600,
                padding: "3px 8px 1px",
                border: "1px solid rgba(216,210,194,0.4)",
                color: "var(--tsp-paper)",
                letterSpacing: "0.1em"
              }}>{k}</div>
              <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.18em", color: "rgba(216,210,194,0.6)" }}>
                {l.toUpperCase()}
              </div>
            </div>
          ))}
        </div>
        <div className="t-hand" style={{ fontSize: 16, color: "var(--tsp-ice-glow)", opacity: 0.85 }}>
          il rifugio · 4.2 km a nord-est
        </div>
      </div>

      {/* contextual flag — quest active */}
      <div style={{
        position: "absolute", left: "50%", top: 200, transform: "translateX(-50%) rotate(-1deg)",
        background: "rgba(216,210,194,0.94)",
        padding: "12px 22px 10px",
        boxShadow: "0 8px 22px rgba(0,0,0,0.5)",
        textAlign: "center"
      }}>
        <div className="t-label" style={{ color: "var(--tsp-rust)", fontSize: 9 }}>OBIETTIVO ATTIVO</div>
        <div className="t-serif" style={{ fontSize: 16, marginTop: 4, fontStyle: "italic" }}>
          "Trova il segnale del padre"
        </div>
        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.18em", color: "var(--tsp-slate)", marginTop: 4 }}>
          STAGE 2 / 7 · MAIN
        </div>
      </div>
    </div>
  );
}

// ====================================================================
// VARIANT B — Open journal spread (book metaphor)
// ====================================================================
function GameScreenB({ mood = "day" }) {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", background: "#1a1d22", overflow: "hidden" }}>
      {/* desk surface */}
      <div style={{
        position: "absolute", inset: 0,
        background: `
          radial-gradient(ellipse 60% 50% at 50% 40%, rgba(120,130,145,0.12), transparent 70%),
          linear-gradient(180deg, #181b21, #0e1115)
        `
      }}/>

      {/* book — two pages */}
      <div style={{
        position: "absolute",
        left: 24, right: 24, top: 24, bottom: 24,
        display: "flex",
        background: "var(--tsp-paper)",
        boxShadow: "0 30px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,0,0,0.4)"
      }}>
        {/* spine shadow */}
        <div style={{
          position: "absolute", left: "50%", top: 0, bottom: 0, width: 40,
          transform: "translateX(-50%)",
          background: "radial-gradient(ellipse 100% 100% at center, rgba(20,24,30,0.35), transparent 70%)",
          pointerEvents: "none", zIndex: 10
        }}/>
        <div style={{
          position: "absolute", left: "50%", top: 0, bottom: 0, width: 2,
          background: "rgba(20,24,30,0.55)",
          transform: "translateX(-50%)",
          zIndex: 11
        }}/>

        {/* LEFT PAGE — Status + map vignette */}
        <div className="paper" style={{ flex: 1, padding: "32px 36px 32px 44px", position: "relative" }}>
          <PageHeader chapter="III" day={14} time="06:42" location="Le Spine" weather="nebbia fitta"/>

          <div style={{ display: "flex", gap: 24, marginTop: 18 }}>
            {/* identity block */}
            <div style={{ flex: 1 }}>
              <div className="t-label" style={{ marginBottom: 10 }}>SOPRAVVISSUTO</div>
              <div className="t-serif" style={{ fontSize: 24, lineHeight: 1, marginBottom: 2 }}>Ultimo</div>
              <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", opacity: 0.9 }}>
                figlio del custode
              </div>
              <div className="t-sans" style={{ fontSize: 11, marginTop: 12, color: "var(--tsp-slate)", letterSpacing: "0.08em" }}>
                lv. 4 · 320 / 500 xp · scavenger
              </div>
              <hr className="ink-rule-dashed" style={{ margin: "16px 0" }}/>
              <div className="t-label-sm" style={{ marginBottom: 8 }}>ABILITÀ PRIMARIE</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 16px" }}>
                {[["FOR", 12],["DES", 14],["COS", 11],["INT", 13],["SAG", 15],["CAR", 9]].map(([k,v]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px dotted rgba(20,24,30,0.3)", padding: "3px 0" }}>
                    <span className="t-sans" style={{ fontSize: 10, letterSpacing: "0.18em", color: "var(--tsp-slate)" }}>{k}</span>
                    <span className="t-serif" style={{ fontSize: 14 }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* stats column */}
            <div style={{ flex: 1.2 }}>
              <div className="t-label" style={{ marginBottom: 10 }}>STATO FISICO</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
                <StatMeter label="VITA"     value={68} max={100} color="rust"/>
                <StatMeter label="SAZIETÀ"  value={42} max={100} color="ink"/>
                <StatMeter label="ACQUA"    value={31} max={100} color="slate"/>
                <StatMeter label="FATICA"   value={78} max={100} color="ink"/>
                <StatMeter label="MENTE"    value={55} max={100} color="mint"/>
              </div>

              <hr className="ink-rule-dashed" style={{ margin: "16px 0" }}/>

              <div className="t-label-sm" style={{ marginBottom: 8 }}>CONDIZIONI</div>
              <div className="t-hand" style={{ fontSize: 15, color: "var(--tsp-rust)", lineHeight: 1.6 }}>
                · ferito (gamba destra)<br/>
                · affamato<br/>
                · disidratato lieve
              </div>

              <hr className="ink-rule-dashed" style={{ margin: "16px 0" }}/>

              <div className="t-label-sm" style={{ marginBottom: 8 }}>EQUIPAGGIAMENTO</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                <ResourceLine label="ARMA" val="Coltello da campo" />
                <ResourceLine label="ARMATURA" val="Giubbotto consunto" />
                <ResourceLine label="ZAINO" val="8.4 / 15 kg" accent />
              </div>
            </div>
          </div>

          {/* footer of left page */}
          <div style={{ position: "absolute", bottom: 16, left: 44, right: 36, display: "flex", justifyContent: "space-between" }}>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>— pag. 47 —</div>
            <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-slate)" }}>S.P. · 14 / IX</div>
          </div>
        </div>

        {/* RIGHT PAGE — Map vignette + journal entries */}
        <div className="paper" style={{ flex: 1, padding: "32px 44px 32px 36px", position: "relative" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", borderBottom: "1.5px solid var(--tsp-ink)", paddingBottom: 8, marginBottom: 14 }}>
            <div className="t-label">DOVE SONO</div>
            <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.22em", color: "var(--tsp-slate)" }}>
              SCHIZZO · MATTINA
            </div>
          </div>

          {/* map vignette */}
          <div style={{
            position: "relative", width: "100%", aspectRatio: "16/10",
            border: "1.5px solid var(--tsp-ink)",
            marginBottom: 16,
            background: "#cdcdc2",
            overflow: "hidden"
          }}>
            <PaperMap mood={mood} showCompass={true}/>
          </div>

          {/* legend */}
          <div style={{ display: "flex", gap: 18, fontSize: 10, marginBottom: 16, flexWrap: "wrap" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--tsp-rust)", display: "inline-block" }}/>
              <span className="t-sans" style={{ letterSpacing: "0.16em", color: "var(--tsp-slate)" }}>POSIZIONE</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ width: 8, height: 8, background: "var(--tsp-paper)", border: "1.5px solid var(--tsp-ink)" }}/>
              <span className="t-sans" style={{ letterSpacing: "0.16em", color: "var(--tsp-slate)" }}>RIFUGIO</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontSize: 12, color: "var(--tsp-rust)" }}>✦</span>
              <span className="t-sans" style={{ letterSpacing: "0.16em", color: "var(--tsp-slate)" }}>OBIETTIVO</span>
            </div>
          </div>

          <hr className="ink-rule-dashed"/>

          {/* mini journal */}
          <div style={{ marginTop: 14 }}>
            <div className="t-label-sm" style={{ marginBottom: 10 }}>ULTIME ANNOTAZIONI</div>
            <JournalEntry time="06:42">L'alba ti coglie sul ciglio della collina. La nebbia divora i campi.</JournalEntry>
            <JournalEntry time="06:15" tone="rust">Una sagoma si è mossa nei rovi. Sei rimasto fermo.</JournalEntry>
            <JournalEntry time="05:30" hand={true} tone="mint">— Domani trovo l'acqua. Domani sempre.</JournalEntry>
          </div>

          {/* footer of right page */}
          <div style={{ position: "absolute", bottom: 16, left: 36, right: 44, display: "flex", justifyContent: "space-between" }}>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>WASD MUOVITI · I INV · J QUEST · E AGISCI</div>
            <div className="t-sans" style={{ fontSize: 9, letterSpacing: "0.32em", color: "var(--tsp-slate-light)" }}>— pag. 48 —</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ====================================================================
// VARIANT C — Cartographer's table / corkboard
// ====================================================================
function GameScreenC({ mood = "day" }) {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden" }}>
      {/* dark cork-leather desk */}
      <div style={{
        position: "absolute", inset: 0,
        background: `
          radial-gradient(ellipse 80% 60% at 50% 50%, #2a2620, #14110d 100%)
        `
      }}/>
      <div style={{
        position: "absolute", inset: 0, opacity: 0.18, pointerEvents: "none",
        backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='400' height='400'><filter id='n'><feTurbulence baseFrequency='1.2' numOctaves='2' seed='9'/></filter><rect width='400' height='400' filter='url(%23n)'/></svg>\")",
        mixBlendMode: "overlay"
      }}/>

      {/* big map in center */}
      <div style={{
        position: "absolute",
        left: 200, top: 60, width: 720, height: 500,
        transform: "rotate(-1deg)",
        boxShadow: "0 30px 60px rgba(0,0,0,0.7)",
      }}>
        <div style={{ position: "relative", width: "100%", height: "100%", background: "#c8c9c0" }}>
          <PaperMap mood={mood} showCompass={true}/>
        </div>
        <Pin top={-7} left={-7} variant="rust"/>
        <Pin top={-7} right={-7} variant="bone"/>
        <Pin bottom={-7} left={-7} variant="bone"/>
        <Pin bottom={-7} right={-7} variant="rust"/>
        {/* coordinate label */}
        <div style={{
          position: "absolute", left: -2, top: -22,
          padding: "2px 8px",
          background: "var(--tsp-paper)",
          fontFamily: "var(--tsp-sans)",
          fontSize: 10, letterSpacing: "0.32em", color: "var(--tsp-ink)",
          boxShadow: "0 2px 4px rgba(0,0,0,0.4)"
        }}>
          ZONA 14 · LE SPINE
        </div>
      </div>

      {/* left column — character ID card + stats */}
      <div style={{
        position: "absolute", left: 32, top: 56, width: 152,
        background: "var(--tsp-paper)",
        padding: "14px 14px 12px",
        transform: "rotate(-2deg)",
        boxShadow: "0 10px 20px rgba(0,0,0,0.5)"
      }}>
        <div className="t-label-sm" style={{ marginBottom: 6 }}>SCHEDA</div>
        <div className="tsp-photo" style={{ width: "100%", aspectRatio: "1/1.1", marginBottom: 8 }}>
          <svg viewBox="0 0 100 110" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
            <rect width="100" height="110" fill="#2a3340"/>
            <circle cx="50" cy="42" r="22" fill="#3a4654"/>
            <path d="M 18 110 Q 50 70 82 110 Z" fill="#3a4654"/>
            <path d="M 38 38 L 36 50 M 62 38 L 64 50" stroke="#1a1d22" strokeWidth="1.2"/>
          </svg>
        </div>
        <div className="t-serif" style={{ fontSize: 17, fontWeight: 500, lineHeight: 1 }}>Ultimo</div>
        <div className="t-hand" style={{ fontSize: 12, color: "var(--tsp-slate)", marginTop: 2 }}>figlio del custode</div>
        <hr className="ink-rule-dashed" style={{ margin: "8px 0" }}/>
        <div className="t-sans" style={{ fontSize: 10, color: "var(--tsp-slate)", letterSpacing: "0.1em", display: "flex", justifyContent: "space-between" }}>
          <span>LV. 4</span>
          <span>SCAVENGER</span>
        </div>
        <div className="t-sans" style={{ fontSize: 9, color: "var(--tsp-slate-light)", letterSpacing: "0.1em" }}>320 / 500 XP</div>
        <Tape top={-12} left={50} w={50} h={18} rot={3}/>
      </div>

      {/* stats sticky note */}
      <div style={{
        position: "absolute", left: 32, top: 360, width: 152,
        background: "#cfc8b6",
        padding: "12px 12px 10px",
        transform: "rotate(2deg)",
        boxShadow: "0 8px 18px rgba(0,0,0,0.45)"
      }}>
        <div className="t-label-sm" style={{ marginBottom: 6 }}>STATO</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <StatMeter label="VITA"    value={68} max={100} color="rust"  compact/>
          <StatMeter label="SAZ."    value={42} max={100} color="ink"   compact/>
          <StatMeter label="ACQUA"   value={31} max={100} color="slate" compact/>
          <StatMeter label="FATICA"  value={78} max={100} color="ink"   compact/>
        </div>
        <hr className="ink-rule-dashed" style={{ margin: "8px 0" }}/>
        <div className="t-hand" style={{ fontSize: 13, color: "var(--tsp-rust)", lineHeight: 1.3 }}>
          ferito, affamato
        </div>
        <Pin top={-7} left={68} variant="bone"/>
      </div>

      {/* right column — diary on top */}
      <div style={{
        position: "absolute", right: 32, top: 56, width: 240,
        background: "var(--tsp-paper)",
        padding: "16px 16px 14px",
        transform: "rotate(1.5deg)",
        boxShadow: "0 10px 22px rgba(0,0,0,0.5)"
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <div className="t-label">DIARIO</div>
          <div className="t-sans" style={{ fontSize: 9, color: "var(--tsp-slate-light)", letterSpacing: "0.16em" }}>OGGI</div>
        </div>
        <hr className="ink-rule" style={{ margin: "8px 0 12px" }}/>
        <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
          <JournalEntry time="06:42">L'alba ti coglie sul ciglio. La nebbia divora i campi.</JournalEntry>
          <JournalEntry time="06:15" tone="rust">Una sagoma si è mossa nei rovi.</JournalEntry>
          <JournalEntry time="05:50">Hai bevuto le ultime gocce.</JournalEntry>
          <JournalEntry time="05:30" hand={true} tone="mint">— Domani trovo l'acqua.</JournalEntry>
        </div>
        <Tape top={-10} right={70} w={70} h={18} rot={-5}/>
      </div>

      {/* objective card pinned right */}
      <div style={{
        position: "absolute", right: 56, top: 380, width: 200,
        background: "#cfc8b6",
        padding: "12px 14px",
        transform: "rotate(-3deg)",
        boxShadow: "0 8px 18px rgba(0,0,0,0.45)"
      }}>
        <div className="t-label-sm" style={{ color: "var(--tsp-rust)", marginBottom: 4 }}>OBIETTIVO</div>
        <div className="t-serif" style={{ fontSize: 15, fontStyle: "italic", lineHeight: 1.25, marginBottom: 8 }}>
          "Trova il segnale del padre"
        </div>
        <div className="t-sans" style={{ fontSize: 9, color: "var(--tsp-slate)", letterSpacing: "0.18em" }}>
          STAGE 2/7 · NORD-EST · 4.2 KM
        </div>
        <Pin top={-7} left={94} variant="rust"/>
      </div>

      {/* clock / weather card */}
      <div style={{
        position: "absolute", right: 60, bottom: 90, width: 180,
        background: "var(--tsp-paper)",
        padding: "10px 14px 10px",
        transform: "rotate(2deg)",
        boxShadow: "0 8px 18px rgba(0,0,0,0.45)"
      }}>
        <div className="t-label-sm" style={{ marginBottom: 4 }}>OGGI</div>
        <div className="t-serif" style={{ fontSize: 22, lineHeight: 1 }}>06:42</div>
        <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", marginTop: 2 }}>nebbia fitta</div>
        <hr className="ink-rule-dashed" style={{ margin: "6px 0" }}/>
        <div className="t-sans" style={{ fontSize: 9, color: "var(--tsp-slate)", letterSpacing: "0.16em" }}>GIORNO 14 · CAP. III</div>
      </div>

      {/* bottom action bar — keyboard hints */}
      <div style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        padding: "14px 32px",
        background: "linear-gradient(0deg, rgba(0,0,0,0.7), transparent)",
        display: "flex", justifyContent: "center", gap: 24
      }}>
        {[
          ["WASD", "muoviti"],
          ["I", "inventario"],
          ["J", "quest"],
          ["F", "cerca"],
          ["R", "riposa"],
          ["E", "agisci"],
        ].map(([k, l]) => (
          <div key={k} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div className="t-sans" style={{
              fontSize: 10, fontWeight: 600, padding: "2px 6px",
              border: "1px solid rgba(216,210,194,0.4)",
              color: "var(--tsp-paper)", letterSpacing: "0.1em"
            }}>{k}</div>
            <div className="t-sans" style={{ fontSize: 10, color: "rgba(216,210,194,0.55)", letterSpacing: "0.16em" }}>
              {l.toUpperCase()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { GameScreenA, GameScreenB, GameScreenC });
