// GameOver.jsx — final journal page, the end of the journey

function GameOver() {
  return (
    <div style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden",
      background: "radial-gradient(ellipse 50% 40% at 50% 50%, #14171d, #050608)"
    }}>
      {/* dust / ash falling */}
      {Array.from({ length: 40 }).map((_, i) => (
        <div key={i} style={{
          position: "absolute",
          width: 1 + (i % 3) * 0.5,
          height: 1 + (i % 3) * 0.5,
          left: `${(i * 41) % 100}%`,
          top: `${(i * 17) % 100}%`,
          background: "rgba(220,228,235,0.35)",
          borderRadius: "50%",
          filter: "blur(0.3px)"
        }}/>
      ))}

      {/* the closing page */}
      <div className="paper" style={{
        position: "absolute",
        left: "50%", top: "50%",
        transform: "translate(-50%, -50%) rotate(-0.8deg)",
        width: 600, padding: "56px 60px 48px",
        boxShadow: "0 50px 100px rgba(0,0,0,0.9), 0 0 0 1px rgba(0,0,0,0.4)"
      }}>
        {/* dark blood/stain */}
        <div style={{
          position: "absolute", top: -8, left: 80,
          width: 100, height: 30,
          background: "radial-gradient(ellipse, rgba(125,58,42,0.55), transparent 70%)",
          filter: "blur(3px)", pointerEvents: "none"
        }}/>

        <div className="t-sans" style={{ fontSize: 10, letterSpacing: "0.5em", color: "var(--tsp-rust)", marginBottom: 8 }}>
          ULTIMA VOCE · DIARIO INTERROTTO
        </div>
        <div className="t-serif" style={{ fontSize: 56, lineHeight: 0.92, fontWeight: 500, letterSpacing: "-0.015em", marginBottom: 18 }}>
          Il quattordicesimo giorno.
        </div>
        <hr className="ink-rule" style={{ marginBottom: 24 }}/>

        <p className="t-serif" style={{ fontSize: 18, lineHeight: 1.7, color: "var(--tsp-ink)", marginBottom: 18, textWrap: "pretty" }}>
          Le mani gli tremavano troppo per scrivere ancora.
          La nebbia era entrata nei polmoni come un secondo respiro,
          uno che non era il suo.
        </p>
        <p className="t-serif" style={{ fontSize: 18, lineHeight: 1.7, color: "var(--tsp-ink-faded)", fontStyle: "italic", marginBottom: 18, textWrap: "pretty" }}>
          Aveva fatto come gli aveva detto suo padre, per anni. Non aveva
          guardato indietro. Forse — pensò — avrebbe dovuto.
        </p>
        <p className="t-serif" style={{ fontSize: 18, lineHeight: 1.7, color: "var(--tsp-ink)", marginBottom: 18, textWrap: "pretty" }}>
          La pagina rimase aperta sul tavolo del rifugio per <em>undici giorni</em>
          prima che qualcuno la trovasse. E quando la trovò, fu solo un'ombra in più
          tra le ombre delle Spine.
        </p>

        <hr className="ink-rule-dashed" style={{ marginBottom: 18 }}/>

        {/* cause + stats — stamp-like */}
        <div style={{ display: "flex", gap: 24, marginBottom: 22 }}>
          <div style={{ flex: 1 }}>
            <div className="t-label-sm" style={{ marginBottom: 4, color: "var(--tsp-rust)" }}>CAUSA</div>
            <div className="t-serif" style={{ fontSize: 17, fontStyle: "italic" }}>
              Esposizione · nebbia
            </div>
            <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", marginTop: 2 }}>
              non c'era riparo
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <div className="t-label-sm" style={{ marginBottom: 4 }}>HA CAMMINATO</div>
            <div className="t-serif" style={{ fontSize: 17 }}>14 giorni · 92 km</div>
            <div className="t-hand" style={{ fontSize: 14, color: "var(--tsp-slate)", marginTop: 2 }}>
              ha incontrato 7 persone
            </div>
          </div>
        </div>

        {/* counted memories */}
        <div className="t-label-sm" style={{ marginBottom: 6 }}>RICORDA, DI LUI</div>
        <div className="t-hand" style={{ fontSize: 16, color: "var(--tsp-ink)", lineHeight: 1.5 }}>
          · ha salvato Liam dai predoni<br/>
          · non ha risposto a sua sorella, quel giorno<br/>
          · ha trovato il talismano del padre<br/>
          · non ha mai mangiato da solo
        </div>

        {/* signature stamp */}
        <Stamp rotate={-12} color="rust" style={{ position: "absolute", bottom: 32, right: 36 }}>FINE · ELIAN</Stamp>

        <div className="t-hand" style={{ fontSize: 16, color: "var(--tsp-slate)", marginTop: 22, fontStyle: "italic" }}>
          — qui finisce il diario di Ultimo, figlio del custode —
        </div>
      </div>

      {/* very subtle "tu sei morto" — absent. instead actions at bottom */}
      <div style={{ position: "absolute", bottom: 40, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 14 }}>
        <div className="tsp-btn" style={{
          color: "var(--tsp-paper)",
          borderColor: "rgba(216,210,194,0.4)",
          background: "transparent",
          padding: "12px 28px 10px"
        }}>
          CARICA L'ULTIMO SALVATAGGIO
        </div>
        <div className="tsp-btn tsp-btn-rust" style={{
          padding: "12px 28px 10px"
        }}>
          UN NUOVO SOPRAVVISSUTO
        </div>
        <div className="tsp-btn tsp-btn-ghost" style={{ color: "var(--tsp-paper-edge)", padding: "12px 28px 10px" }}>
          MENU PRINCIPALE
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 14, left: 0, right: 0, textAlign: "center" }}>
        <span className="t-sans" style={{ fontSize: 9, letterSpacing: "0.5em", color: "rgba(216,210,194,0.35)" }}>
          IL MONDO CONTINUA SENZA DI TE
        </span>
      </div>
    </div>
  );
}

Object.assign(window, { GameOver });
